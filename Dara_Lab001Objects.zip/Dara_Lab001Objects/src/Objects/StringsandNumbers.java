/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Objects;

import java.util.Random;

/**
 *
 * @author Dara,Sandeep Kumar
 */
public class StringsandNumbers {
   
       public static void main(String[] args){
     //1.a(i-vii) Declaring all the strings.
        String string1 = "   Welcome";
        String string2 = "   to  ";
        String string3 = "Computer";
        String string4 = " Science     ";
        String string5 = " and ";
        String string6 = "  Information    ";
        String string7 = "Systems   ";
        
     //1.b String concatenation.
        String string8 = string1.concat(string2).concat(string3).concat(string4).concat(string5).concat(string6).concat(string7);
      
        //1.c)Printing length of concatenated string.
      
        System.out.println( "The length of the concatenated string is:"+string8.length());
        
        //1.d) Removing empty spaces from string 
        String string9 =string4.trim();
        System.out.println( "Length of the trimmed string is:"+string9.length());
        
      //1.e) Printing the index of e.
      int a= string8.indexOf("Science");
       //System.out.println(a);
      String string10=string8.substring(a,a+string9.length());
      System.out.println("Index of first e in science is:"+string10.indexOf("e"));
      
      //2) Index and Substring functions.
      String string11="rnururrunngisnnurun";
       System.out.println("First occurrence of word run is:"+ string11.indexOf("run"));
       int lr=string11.indexOf("run");
       String string12 = string11.substring(lr, lr+"run".length());
       //System.out.println(string12);
       int li = string11.indexOf("is");
       String string13 = string11.substring(li, li+"is".length());
       //System.out.println(string13);
       String string14 = string12.concat(string13);
       String string15 =string14.concat("fun");
     System.out.println(string15);
     
     //3.Math methods
     
     //3.a.i) Printing one value to the raised other value.
       int myValue1=4;
       int myValue2=6;
      
       System.out.println(Math.pow(myValue1, myValue2));//using math.pow() function
       //3.a.ii) Printing ceil and floor values of result.
       double myNumber=26.30;
       double squareroot = Math.sqrt(myNumber);
       System.out.println("Square root of the number is:"+squareroot);
       System.out.println("Ceil Value is:"+Math.ceil(myNumber));
        System.out.println("Floor Value is:"+Math.floor(myNumber));
        
        //3.a.iii) printing sine and tan values of numbers.
        double myNumber1=30;
        double myNumber2=75;
        System.out.println(Math.round(Math.sin(myNumber1)));
        System.out.println(Math.round(Math.sin(myNumber2)));
        System.out.println(Math.round(Math.tan(myNumber1)));
        System.out.println(Math.round(Math.tan(myNumber2)));  
        
 
//3.b) Printing ceil value using function.

double result = (Math.ceil(Math.sinh(Math.sqrt((Math.pow(5,2))+(4*3*3)+2)/(3*2))));
           System.out.println(result);
          


//4.a)Generating random numbers using seed value of 10L.

 Random seed = new Random( 10L );

    
     //int value = seed.nextInt( 200 );
     System.out.println( "\nFirst Random value:" +seed.nextInt(200));
     System.out.println( "Second Random value:" +seed.nextInt(200));
     System.out.println( "Third Random value:" +seed.nextInt(200));
     System.out.println( "Fourth Random value:" +seed.nextInt(200));
     System.out.println( "Fifth Random value:" +seed.nextInt(200));
     System.out.println( "Sixth Random value:" +seed.nextInt(200));
     System.out.println( "Seventh Random value:" +seed.nextInt(200));
     
     
   
//4.b)Printing the random values.
System.out.println("\n4.b: Random values does not change when seed value of 10L is passed.  \n");


//4.c)Generating random numbers without seed value. 
 Random noseed = new Random( );

     System.out.println("First Random value:" +noseed.nextInt(200));
     System.out.println("Second Random value:" +noseed.nextInt(200) );
     System.out.println("Third Random value:" +noseed.nextInt(200));
     System.out.println("Fourth Random value:" +noseed.nextInt(200));
     System.out.println("Fifth Random value:" +noseed.nextInt(200));
     System.out.println("Sixth Random value:" +noseed.nextInt(200));
     System.out.println("Seventh Random value:" +noseed.nextInt(200));
     System.out.println("\nValues are generated randomly when noseed value is passed. ");
     

//4.d)Comparing the results with seed value and without seed values.
System.out.println("\n4.d When a seed value is passed as an parameter,random values does not change.\nWhen no seed value is passed the random values are generated and they keep \non changing from one execution to other.\n");
    }
}

    



         
       
       
       
       
       
       
       
        
                
        
       
       
        
        
                                        
                                        
                                        
                                        
    
    

