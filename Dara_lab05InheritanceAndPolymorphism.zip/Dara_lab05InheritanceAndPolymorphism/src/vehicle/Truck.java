/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicle;

import java.util.ArrayList;

/**
 *This is Truck class which is inherited from FourWheeler class
 * @author Dara,Sandeep kumar
 */
public class Truck extends FourWheeler{
    private String name;
    private final double BASE_PRICE=30.0;

    /**
     *This is default constructor
     */
    public Truck() {
        super();
    }

    /**
     *This is parameterized constructor with the variables of Vehicle class
     * @param manufacturerName name of the manufacturer
     * @param v_Id Vehicle Identification number
     */
    public Truck(String manufacturerName, int v_Id) {
        super(manufacturerName,v_Id);
        this.name = "Truck";
//        this.BASE_PRICE = BASE_PRICE;
    } 

    /**
     *This method calculates the cost of Extra fittings for truck
     * @return Returns the cost of Extra fittings
     */
    public double calculateExtraFittingCost(){
        double baseprice=0;
        
        for(String values:getAccessories()){
            
            
if(values.equalsIgnoreCase("Floor Mats")){
    baseprice+=39;  
}
else if(values.equalsIgnoreCase("Side Covers")){
    baseprice+=50;  
}
else if(values.equalsIgnoreCase("Headlights")){
    baseprice+=90;  
}
else if(values.equalsIgnoreCase("Custom Grilles")){
    baseprice+=101;  
}

else if(values.equalsIgnoreCase("Audio System")){
    baseprice+=70;  
}
else{
    return BASE_PRICE;
}           
}      
  return BASE_PRICE+baseprice;      
    }     
     /**
     * @return Returns the String representation of an object
     */
    @Override
    public String toString() {
        return super.toString()+"Manufacturer Name:" +getManufacturerName() + "\nVehicle Id:" +getV_Id()+"\nType of Vehicle:"+name+"\nThe total cost of Extra Interiors is:"+calculateExtraFittingCost();
    }
    
    }

