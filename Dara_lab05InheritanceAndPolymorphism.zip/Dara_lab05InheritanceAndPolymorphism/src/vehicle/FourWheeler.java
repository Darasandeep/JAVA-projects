/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicle;

import java.util.ArrayList;

/**
 *This is FourWheeler class which is inherited from Vehicle class
 * @author Dara,Sandeep kumar
 */
public class FourWheeler extends Vehicle{
    private ArrayList<String> accessories=new ArrayList<String>();

    /**
     *This is default constructor
     */
    public FourWheeler() {
        super();
    }

   /**
     *This is parameterized constructor with the variables of super class
     * @param manufacturerName name of the manufacturer
     * @param v_Id Vehicle Identification number
     */
    public FourWheeler(String manufacturerName, int v_Id) {
        super(manufacturerName,v_Id);
        this.accessories=accessories;
        
    }

    /**
     *Accessor
     * @return returns the elements of ArrayList accessories
     */
    public ArrayList<String> getAccessories() {
        return accessories;
    }

    /**
     *Mutator
     * @param accessories ArrayList of accessories
     */
    public void setAccessories(ArrayList<String> accessories) {
        this.accessories = accessories;
    }

    /**
     *This method adds Accessories to ArrayList
     * @param items Items that are to be added as extra fittings
     * @return returns the elements of ArrayList accessories after adding extra fittings
     */
    public ArrayList<String> addAccessories(String items) {
         String[] accs=items.split(",");
         for(String i:accs){
       accessories.add(i);
                    }
         
    return accessories;  
     }
    /**
     * @return Returns the String representation of an object
     */
    @Override
    public String toString() {
        return "Four Wheeler Details:\n" ;
    }
     
    
    
    
    
    
}
