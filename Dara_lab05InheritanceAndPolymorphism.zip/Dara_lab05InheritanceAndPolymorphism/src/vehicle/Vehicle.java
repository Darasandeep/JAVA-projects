/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicle;

/**
 *This is vehicle class
 * @author Dara,Sandeep kumar
 */
public class Vehicle {
    private String manufacturerName;
    private int v_Id;

    /**
     *This is default constructor
     */
    public Vehicle() {
    }

    /**
     *This is parameterized constructor
     * @param manufacturerName name of the manufacturer
     * @param v_Id Vehicle Identification number
     */
    public Vehicle(String manufacturerName, int v_Id) {
        this.manufacturerName = manufacturerName;
        this.v_Id = v_Id;
    }

    /**
     * Accessor
     * @return returns the ManufacturerName
     */
    public String getManufacturerName() {
        return manufacturerName;
    }

    /**
     * Mutator
     * @param manufacturerName name of the manufacturer
     */
    public void setManufacturerName(String manufacturerName) {
        this.manufacturerName = manufacturerName;
    }

    /**
     * Accessor.
     * @return returns the Vehicle Identification number
     */
    public int getV_Id() {
        return v_Id;
    }

    /**
     *Mutator
     * @param v_Id Vehicle Identification number
     */
    public void setV_Id(int v_Id) {
        this.v_Id = v_Id;
    }
    /**
     * @return Returns the String representation of an object
     */
    @Override 
    public String toString() {
        return  "ManufacturerName:" + getManufacturerName() + " Vehicle Id:" + getV_Id();
    }
    
    
    
}
