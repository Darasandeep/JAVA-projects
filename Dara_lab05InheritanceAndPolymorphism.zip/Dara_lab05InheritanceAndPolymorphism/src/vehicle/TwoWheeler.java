/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicle;

/**
 *This is TwoWheeler class which is inherited from Vehicle class
 * @author Dara,Sandeep kumar
 */
public class TwoWheeler extends Vehicle{
    private String message;

    /**
     *This is default constructor
     */
    public TwoWheeler() {
        super();
    }

    /**
     *This is parameterized constructor with the variables of Superclass
     * @param manufacturerName name of the manufacturer
     * @param v_Id Vehicle Identification number
     */
    public TwoWheeler(String manufacturerName, int v_Id) {
        super(manufacturerName,v_Id);
        this.message=" ";
    }

    /**
     *This is identifier method which determines the type of bike based on fuel used
     * @param category Fuel type used to run the Vehicle
     * @return returns the type of vehicle
     */
    public String Identifier(String category){
        if(category.equalsIgnoreCase("Petrol")){
            message="is a super bike";
            return message;
        }
        else{
            message="is a cycle ";
            return message;
        }
        
    }
     /**
     * @return Returns the String representation of an object
     */
    @Override
    public String toString() {
        return "Manufacturer Name:" +super.getManufacturerName() + "\nVehicle Id:" +super.getV_Id();
    }
    
}
