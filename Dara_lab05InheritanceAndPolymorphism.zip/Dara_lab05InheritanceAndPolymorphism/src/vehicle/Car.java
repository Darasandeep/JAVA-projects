/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicle;

/**
 *This is Car class which is inherited from FourWheeler class
 * @author Dara,Sandeep kumar
 */
public class Car extends FourWheeler {
    private String name;
    private long initialDistance;
    private long finalDistance;
    private double initialGasQuantity;
    private double finalGasQuantity;

    /**
     *This is default constructor
     */
    public Car() {
        super();
    }

    /**
     *This is parameterized constructor with six arguments  
     * @param manufacturerName Name of the Manufacturer
     * @param v_Id Identification number of vehicle
     * @param initialDistance initial reading before travel
     * @param finalDistance final reading after travel
     * @param initialGasQuantity    initial gas quantity before travel
     * @param finalGasQuantity  final gas Quantity after travel
     */
    public Car(String manufacturerName,int v_Id, long initialDistance, long finalDistance, double initialGasQuantity ,double finalGasQuantity) {
        super(manufacturerName,v_Id);
        this.name = "Car";
        this.initialDistance = initialDistance;
        this.finalDistance = finalDistance;
        this.initialGasQuantity=initialGasQuantity;
        this.finalGasQuantity = finalGasQuantity;
    }

    /**
     *This method calculates the amount of gas used for traveling
     * @return returns the gas consumed for travel
     */
    public double calculateGas(){
//            initialGasQuantity=(initialGasQuantity*0.264172);
//            System.out.println(initialGasQuantity);
//            finalGasQuantity=(finalGasQuantity*0.264172);
//            System.out.println(finalGasQuantity);
        return (initialGasQuantity-finalGasQuantity)*0.264172;   
        }

    /**
     *This method calculates the distance of travel
     * @return  returns the distance of travel
     */
    public double calculateDistance(){
//            initialDistance=(long) (initialDistance);
//            System.out.println(initialDistance);
//            finalDistance=(long) (finalDistance);
//            System.out.println(finalDistance);
    
            return (finalDistance-initialDistance)*0.62138;
            
            
    }

    /**
     *This method calculates the Mileage of Vehicle
     * @return returns the Mileage of Vehicle
     */
    public double calculateMileage(){
           
  return   (calculateDistance()/calculateGas());
    
    
    
}
     /**
     * @return Returns the String representation of an object
     */
    @Override
    public String toString() {
        return super.toString()+"Manufacturer Name:" +getManufacturerName() + "\nVehicle Id:" +getV_Id()+"\nType of Vehicle:"+name+"\nThe distance travelled is:"+calculateDistance()+"\nThe gas consumed to cover the distance:"+calculateGas()+"\nThe Mileage of the vehicle is:"+calculateMileage();
//        return "Manufacturer Name:"+getManufacturerName()+"\nVehicle Id:"+getV_Id();
    }
}
