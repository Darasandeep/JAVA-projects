/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicle;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

/**
 *This is Driver class.
 * @author Dara,Sandeep kumar
 */
public class VehicleDriver {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException {
      File inputfile =new File("vehicle.txt");
      Scanner sc=new Scanner(inputfile);
      if(inputfile.exists()){
         
        String manufactName = sc.nextLine();
        int v_id =Integer.parseInt(sc.nextLine());
            Vehicle v = new Vehicle(manufactName,v_id);
//        v.setManufacturerName(manufacturerName);
//        v.setV_Id(v_Id);
        System.out.println("Vehicle Details:");
        System.out.println(v.toString());
        System.out.println("*********************************************************");
        
//        System.out.println(v_Id);
//        System.out.println(manufacturerName);
        
        while(sc.hasNext()){
            
          String v_type=sc.nextLine();
            if(v_type.equalsIgnoreCase("four wheeler")){
                String name1=sc.nextLine();
                if(name1.equalsIgnoreCase("car")){
                   long initialDistance=sc.nextInt();
//                    System.out.println(initialDistance);
                        long finalDistance=sc.nextInt();
                        double initialGasQuantity=sc.nextDouble();
                        double finalGasQuantity=sc.nextDouble();
//                        System.out.println(initialDistance+" "+finalDistance+" "+initialGasQuantity+" "+finalGasQuantity);
                       Car c = new Car(manufactName,v_id,initialDistance,finalDistance,initialGasQuantity,finalGasQuantity);
                       System.out.println(c.toString());

                   
                      System.out.println("*********************************************************");
                      
                }
                else if(name1.equalsIgnoreCase("truck")){
                    String accsrs=sc.nextLine();
                    

                    Truck t=new Truck("Maserati",12345);
                   t.addAccessories(accsrs);
                    t.calculateExtraFittingCost();
                    System.out.println(t.toString());

                System.out.println("*********************************************************");
                }
                }
            else if(v_type.equalsIgnoreCase("twowheeler")){
                

                String manName=(sc.nextLine());

                int vid=Integer.parseInt(sc.nextLine());

/**
*we use object of Bike class which is an sub class of Twowheeler which is polymorphic substitution.
*
*/
                TwoWheeler b=new Bike(manName,vid);
                String gastype=sc.nextLine();
//                System.out.println(""+gastype);
                 
                System.out.println(b.toString());
                System.out.println("The TwoWheeler "+b.Identifier(gastype)); 
                System.out.println("*********************************************************");        
            }
            }
                
                
           System.out.println("Congratulations,End of the program!\n");      
        }
      else{
          System.out.println("File not found");
      }
          
    }
}
    

