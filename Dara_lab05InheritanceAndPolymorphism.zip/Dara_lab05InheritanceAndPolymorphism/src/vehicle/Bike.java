/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vehicle;

/**
 *This is Bike class which is inherited from TwoWheeler class
 * @author Dara,Sandeep kumar
 */
public class Bike extends TwoWheeler{
    private String name;

    /**
     *This is default constructor
     */
    public Bike() {
    super();
    }

    /**
     *This is parameterized constructor with the variables of Vehicle class
     * @param manufacturerName name of the manufacturer
     * @param v_Id Vehicle Identification number
     */
    public Bike(String manufacturerName, int v_Id) {
        super(manufacturerName,v_Id);
        this.name = name;
    }
     /**
     * @return Returns the String representation of an object
     */
    @Override
    public String toString() {
        return "Two Wheeler Details:\n"+super.toString();
    }
    
    
    
}
