/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mysonic;

import java.util.Scanner;

/**
 *This is main class
 * @author Dara,Sandeep Kumar
 */
public class SonicDriver {

    /**
     *
     * @param args      Command line argument.
     */
    public static void main(String args[]){
        
      String order; 
        System.out.println("Welcome to Sonic!");
    do{
    
    Scanner sc =new Scanner(System.in);
            System.out.print("Enter the Name of MilkShake: ");
            String milkshakeName =sc.nextLine();
            System.out.print("Enter Contact Number :");
            String contactNumber =sc.nextLine();
            System.out.print("Enter size of milkshake: ");
            String size =sc.nextLine();
            System.out.print("Enter toppings you want to add: ");
            String shakeToppings =sc.nextLine();
            System.out.print("Enter ice cream type you want to add: ");
            String extraIceCream =sc.nextLine();
            System.out.print("Enter order type(Dine In/ Take Away): ");
            String orderType =sc.nextLine();
            System.out.println("********************************************");
            
   SonicOrder so=new SonicOrder();
   
   so.setMilkshakeName(milkshakeName);
   so.setContactNumber(contactNumber);
   so.setSize(size);
   so.setShakeToppings(shakeToppings);
   so.setExtraIceCream(extraIceCream);
   so.setOrderType(orderType);

   
        System.out.println("Your Order :\n"+so.toString());
        System.out.println("********************************************");
        System.out.println("Would you like order again ? (Y/N): ");
        System.out.println("********************************************");

        order =sc.next();
                }
      while("Y".equalsIgnoreCase(order));
    
    
        
        System.out.println("********************************************");
              System.out.println("Thank You and have a great day!");                
    }
          
} 
    

