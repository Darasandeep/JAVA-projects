/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mysonic;

/**
 *This is SonicOrder class
 * @author Dara,Sandeep Kumar
 */
public class SonicOrder {
    
    private String milkshakeName;
    private String orderType;
    private String contactNumber;
    private String size;
    private final double CLASSIC_SHAKE=3.0;
    private final double MASTER_SHAKE=3.50;
    private final double MASTER_BLAST=3.75;
    private final double WAFFLECONE_SUNDAE=4.0;
    private String shakeToppings;
    private String extraIceCream;
    
    /**
     *This is parameterized constructor
     * @param milkshakeName     Name of the milkshake.      
     * @param orderType         Type of Order.   
     * @param contactNumber     Contact number of customer.
     * @param size              Size of Milkshake.
     * 
     * 
     */
    public SonicOrder(String milkshakeName, String orderType, String contactNumber, String size){
 this.milkshakeName= milkshakeName;
 this.orderType=orderType;
 this.contactNumber=contactNumber;
 this.size=size;
}

    /**
     *This is parameterized constructor
     * @param contactNumber
     * 
     */
    public SonicOrder(String contactNumber){
        this.contactNumber= contactNumber;
        this.milkshakeName="Chocolate MilkShake";
        this.orderType="Dine-In";
        this.size="Regular";
    }

    /**
     *This is Default constructor
     */
    public SonicOrder(){

}

    /**
     *
     * @return
     * This method returns the name of milkShake
     */
    public String getMilkshakeName() {
        return milkshakeName;
    }

    /**
     *
     * @param milkshakeName     name of the milk shake
     * This method sets the name of milkShake
     */
    public void setMilkshakeName(String milkshakeName) {
        this.milkshakeName = milkshakeName;
    }

    /**
     *
     * @return
     * This method returns the Type of order
     */
    public String getOrderType() {
        return orderType;
    }

    /**
     *
     * @param orderType     type of order
     * This method sets the type of order
     */
    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }
    
    /**
     *
     * @return
     * This method returns the ContactNumber of Customer
     */
    public String getContactNumber() {
        return contactNumber;
    }

    /**
     *
     * @param contactNumber   ContactNumber of Customer
     * This method sets the ContactNumber of Customer
     */
    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    /**
     *
     * @return
     * This method returns the  Size of MilkShake
     */
    public String getSize() {
        return size;
    }

    /**
     *
     * @param size   size of milkShake
     * This method sets the  Size of MilkShake
     */
    public void setSize(String size) {
        this.size = size;
    }

    /**
     *
     * @return
     * This method returns the  ShakeToppings
     */
    public String getShakeToppings() {
        return shakeToppings;
    }

    /**
     *
     * @param shakeToppings  Toppings on the Icecreams; 
     * This method sets the  ShakeToppings
     */
    public void setShakeToppings(String shakeToppings) {
        this.shakeToppings = shakeToppings;
    }

    /**
     *
     * @return
     * This method returns the ExtraIceCream.
     */
    public String getExtraIceCream() {
        return extraIceCream;
    }

    /**
     *
     * @param extraIceCream   Extrascoops of Icecreams 
     * This method sets the ExtraIceCream.
     */
    public void setExtraIceCream(String extraIceCream) {
        this.extraIceCream = extraIceCream;
    }

    /**
     *
     * @return
     * This method returns the value of total number of toppings
     */
    public double getTotalNumberToppings(){
       
        String toppings=shakeToppings;
        String[] parts=toppings.split(",");
    return parts.length;
    }

    /**
     *
     * @return
     * This method returns the value of total number of scoops
     */
    public double getTotalNumberScoops(){
    String icecream =extraIceCream;
        String[] parts=extraIceCream.split(",");
    return parts.length;
    }

    /**
     *
     * @return
     * This method calculates and returns the cost of TotalScoops
     */
    public double getTotalScoopsCost(){
        String icecream =extraIceCream;
        String[] parts=extraIceCream.split(",");
    
  
    double cost=0;
    for(int i=0;i<parts.length;i++){
    switch(parts[i])
    {
                  case  "Vanilla":
                cost=cost+1.0;
                break;
                  case  "Chocolate":
                cost=cost+1.25;
                break;
                  case  "Butterscotch":
                cost=cost+2.5;
                break;
                  case  "Strawberry":
                cost=cost+2.75;
                break;
                  case  "Blackberry":
                cost=cost+2.25; 
                break;
                  case  "Caramel":
                cost=cost+2.5;
                break;
                  case  "others" :
                cost=cost+3.0;
                break;
    }
       } 
    return cost;
    
    }

    /**
     *
     * @return
     * This method  calculates and returns the Cost of TotalToppings
     */
    public double getTotalToppingsCost(){
        String toppings =shakeToppings;
        String[] parts=shakeToppings.split(",");
    
  
    double cost=0;
    for(int i=0;i<parts.length;i++){
        
    
   if("M&M".equals(parts[i]))
    {
                  
                cost=cost+0.75;
    }      
   else if("Oreo".equals(parts[i]))
    {
                  
                cost=cost+0.65;
    }          
   else if("ChocolateChips".equals(parts[i]))
   {           
                cost=cost+0.99;
    }                 
   else
    {    
                cost=cost+1.0;
    }  
   }
 
    return cost;
    }
     
    /**
     *
     * @return
     * This method calculates and returns the value of totalCost of Order
     */
    public double getTotalCost(){
         double totalCost=0;
         if(milkshakeName.equals("MilkShake"))
         {    
         totalCost=CLASSIC_SHAKE;
         
     }
       else if(milkshakeName.equals("MasterShake"))
         {    
         totalCost = MASTER_SHAKE;
         
     }
        else if(milkshakeName.equals("MasterBlast"))
         {    
         totalCost=MASTER_BLAST;
         
     }
        else if(milkshakeName.equals("Wafflecone"))
         {    
         totalCost=WAFFLECONE_SUNDAE;
         
         }
         else
         {
         totalCost=CLASSIC_SHAKE;
                 } 
         
         String[] toppings =shakeToppings.split(",");
         String[] extraice =extraIceCream.split(",");
         if((toppings.length)>2){
         totalCost= totalCost+1.0;
         }
         if((extraice.length)>1){
         totalCost= (totalCost*1.10);
         }
         
         totalCost=totalCost+getTotalToppingsCost()+getTotalScoopsCost();
         if("Dine In".equalsIgnoreCase(orderType)){
            totalCost= totalCost*0.90;  
         }
         else {
             totalCost= totalCost*1.10;
         }
             
    
         return totalCost;
     }


    @Override //Returns a string representation of the object.
    public String toString() {
        String order = null;
        return  "Contact Number of Customer: " + contactNumber +   "\nMilkshake Ordered by Customer : " + milkshakeName+   "\nSize of Milkshake : " + size + "\nToppings for milk shake : " + shakeToppings + "\nExtra Scoops of Ice-Cream : " + extraIceCream +"\n********************************************" + "\nTotal Cost of YourOrder : "+getTotalCost();

   
     }
}
 
     



    

    
    
    
    


