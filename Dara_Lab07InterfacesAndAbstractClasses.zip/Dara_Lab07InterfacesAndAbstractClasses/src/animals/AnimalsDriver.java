/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animals;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author Dara,Sandeep kumar
 */
public class AnimalsDriver {

    public AnimalsDriver() {
    }
    

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException{
        // TODO code application logic here
        Scanner sc=new Scanner(new File("input.txt"));
        while(sc.hasNext()){
            String type=sc.nextLine();
            if("DomesticAndWildAnimal".equalsIgnoreCase(type)){
                String name=sc.nextLine();
                
                String bodycovered=sc.nextLine();
//                System.out.println(bodycovered);
                boolean Mammal=Boolean.parseBoolean(sc.nextLine());
//                System.out.println(Mammal);
            DomesticAndWildAnimals DomesticAndWildAnimal=new DomesticAndWildAnimals(bodycovered,Mammal);
                System.out.println("This Animal is called as: "+name);
                System.out.println("Number of legs for this Animal: "+DomesticAndWildAnimal.getNumberOfLegs());
                System.out.println("This animal sounds: "+DomesticAndWildAnimal.getAnimalSound(name));
                System.out.println("This animal skin type is: "+DomesticAndWildAnimal.getBodyCovered());
                if(name.equalsIgnoreCase("pig")){
                     System.out.println("getAnimalSound in DomesticatedAnimals is called because we have provided DomesticatedAnimals in the method explicitly");
                    System.out.println("First method is calling the method explicitly using Interfacename.super.methodname()");
                    System.out.println("Second method is to override the default method in class");
                }
                else{
                    System.out.println("getAnimalSound in DomesticatedAnimals is used because we have provided DomesticatedAnimals in the method explicitly");
                    System.out.println("Second method is to override the default method in class");
                }
               
           

                }
            
            else if("ExtinctAnimal".equalsIgnoreCase(type)){
                String name=sc.nextLine();
//                System.out.println(name);
                int yearOfExtinct=Integer.parseInt(sc.nextLine());
//                System.out.println(yearOfExtinct);
                String Animaltype=sc.nextLine();
           ExtinctAnimals ExtinctAnimal=new GiganticExtinctAnimals(yearOfExtinct,Animaltype);
            
                System.out.println("Name of Extinct Animal: "+name);
                System.out.println("Food type of this Animal: "+ExtinctAnimal.getFoodtype());
                System.out.println("Year of Extinct: "+ExtinctAnimal.getYearOfExtinct());
                 System.out.println("It is not mandatory for abstract class to have atleast one abstract method");
                System.out.println("Abstract class cannot be instantiated directly but it can be done using polymorphic substitution");
            }
            else {
                String typeanimal=sc.nextLine();
             
                //dinosaur
                int yearOfExtinct=Integer.parseInt(sc.nextLine());
//               System.out.println(yearOfExtinct);
//              System.out.println(yearOfExtinct);
//                //1100
                String name=sc.nextLine();
                //bronchio
           ExtinctAnimals GiganticExtinctAnimal=new GiganticExtinctAnimals(yearOfExtinct,name);
                System.out.println("Type of Gigantic Extinct Animal: "+typeanimal);
               System.out.println("Name of Extinct Animal: "+GiganticExtinctAnimal.getAnimalType());
                System.out.println("Food type of this Animal: "+GiganticExtinctAnimal.getFoodtype());
                System.out.println("Year of Extinct: "+GiganticExtinctAnimal.getYearOfExtinct());
                System.out.println("class can implement from more than one interface but it cannot extend more than one class");
                
            
            
           
                
                        
                
                
           }
        }
        
    }
    
}
