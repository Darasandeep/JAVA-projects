/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animals;

/**
 *
 * @author Dara,Sandeep kumar
 */
public interface Animals {
    static final int NUMBER_OF_LEGS=4;
    int getNumberOfLegs();
        
    
    
    
}
