/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animals;

/**
 *
 * @author Dara,Sandeep kumar
 */
public interface DomesticatedAnimals extends Animals {
    
    default String getAnimalSound(String animal){
        if(animal.equalsIgnoreCase("dog")){
            return "bow-wow";
        }
        else if(animal.equalsIgnoreCase("cat")){
            return "Meow";
        }
        else{
            return "Domestic Animal Not Found";
        }
        
    }
}
