/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animals;

/**
 *
 * @author Dara,Sandeep kumar
 */
public abstract class ExtinctAnimals implements Animals{
    private String animalType;
    private int yearOfExtinct;
    public abstract String getFoodtype();
    public ExtinctAnimals(int yearOfExtinct,String animalType) {
        this.animalType = animalType;
        this.yearOfExtinct = yearOfExtinct;
    }
            

    @Override
    public int getNumberOfLegs() {
      return NUMBER_OF_LEGS;
    }
   

    public String getAnimalType() {
        return animalType;
    }

    public void setAnimalType(String animalType) {
        this.animalType = animalType;
    }

    public int getYearOfExtinct() {
        return yearOfExtinct;
    }

    public void setYearOfExtinct(int yearOfExtinct) {
        this.yearOfExtinct = yearOfExtinct;
    }

    @Override
    public String toString() {
        return "ExtinctAnimals{" + "animalType=" + animalType + ", yearOfExtinct=" + yearOfExtinct + '}';
    }
    
    
    
    
}
