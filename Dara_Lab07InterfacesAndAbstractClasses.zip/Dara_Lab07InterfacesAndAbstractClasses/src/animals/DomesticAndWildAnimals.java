/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animals;

/**
 *
 * @author Dara,Sandeep kumar
 */
public class DomesticAndWildAnimals implements Animals, DomesticatedAnimals, WildAnimals{
    private String bodyCovered;
    private boolean mammal;

    public DomesticAndWildAnimals(String bodyCovered, boolean mammal) {
        this.bodyCovered = bodyCovered;
        this.mammal = mammal;
    }
    

    @Override
    public int getNumberOfLegs() {
     return NUMBER_OF_LEGS;
    }

    @Override
    public String getAnimalSound(String animal) {
     return DomesticatedAnimals.super.getAnimalSound(animal);
    }

    public String getBodyCovered() {
        return bodyCovered;
    }

    public void setBodyCovered(String bodyCovered) {
        this.bodyCovered = bodyCovered;
    }

    public boolean isMammal() {
        return mammal;
    }

    public void setMammal(boolean mammal) {
        this.mammal = mammal;
    }

    @Override
    public String toString() {
        return "DomesticAndWildAnimals{" + "bodyCovered=" + bodyCovered + ", mammal=" + mammal + '}';
    }
    
}
