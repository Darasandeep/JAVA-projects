/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animals;

/**
 *
 * @author Dara,Sandeep Kumar
 */
public class GiganticExtinctAnimals extends ExtinctAnimals{
    
    public GiganticExtinctAnimals(int yearOfExtinct,String animalType) {
        super(yearOfExtinct,animalType);
    }

    @Override
    public String getFoodtype() {
        if(getAnimalType().equalsIgnoreCase("Brachiosaurus")){
            return "Plant Eater(Herbivores)";
        }
        else if(getAnimalType().equalsIgnoreCase("Baryonyx")){
            return "Meat-eaters (carnivores or theropods)";
        }
        else{
            return "omnivores (eating both plants and animals)";
        }
   
    
      
        }
    @Override
          public int getNumberOfLegs(){
         return NUMBER_OF_LEGS; 
    }
    
}
