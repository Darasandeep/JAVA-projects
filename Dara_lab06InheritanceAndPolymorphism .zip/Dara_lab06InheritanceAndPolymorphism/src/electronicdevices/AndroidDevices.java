/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package electronicdevices ;

import java.util.Date;
import java.text.SimpleDateFormat;

/**
 *
 * @author Dara,Sandeep Kumar
 */
public class AndroidDevices extends Gadgets{
   private double version;

AndroidDevices(double battery, double screenSize, double cost,Date year,String make, double version) {  
 super(battery,screenSize,cost,year,make);
 this.version=version;
}
public String getVersionName(){
String out;
       if(getVersion()<5.0)
           out="Very old Android Device";
       else
           out="Latest Version"; 
    return out;
}
    public double getVersion() {
        
    return version;
    }
    public void setVersion(double version) {
        this.version = version;
    }

    @Override
    public String toString() {
        return super.toString()+" AndroidDevices{" + "version= " + version + '}';
    }
  





}