/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package electronicdevices;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author Dara,Sandeep Kumar
 */
public class ElectronicsDriver {
    public static void main (String args[]) throws FileNotFoundException, ParseException{
        int i=1;
 
        ArrayList<ElectronicDevices> electronic =new ArrayList<>();
     Scanner elec= new Scanner(new File("input.txt"));
     while(elec.hasNext()){
         String type=elec.nextLine();
//        System.out.println(type);
         if(type.equalsIgnoreCase("electronic device")){
             double cost=Double.parseDouble(elec.nextLine());
//             System.out.println(cost);
             String date=elec.nextLine();
//             System.out.println(date);
             
             //SimpleDateFormat year1=new SimpleDateFormat("yyyy-mm-dd");
               Date year=new SimpleDateFormat("MM-dd-yyyy").parse(date);
//               System.out.println(year);
                   String make=elec.nextLine();
                    ElectronicDevices ed=new ElectronicDevices(cost,year,make);
//                   System.out.println(""+cost +date +make);
           System.out.println("Device "+ i +": "+ed);
            electronic.add(ed);
     i++;
         }
         else if("gadget".equalsIgnoreCase(type)){
             double cost=Double.parseDouble(elec.nextLine());
             String date=elec.nextLine();
               Date year=new SimpleDateFormat("MM-dd-yyyy").parse(date);
                   String make=elec.nextLine();
                   double battery=Double.parseDouble(elec.nextLine());
                   double screen=Double.parseDouble(elec.nextLine());
                 ElectronicDevices  gd =new Gadgets(battery,screen,cost,year,make);
             System.out.println("Device "+ i +": "+gd.expensiveOrNot());
             System.out.println("a.calls the expensiveOrNot method in subclass when invoked which is called late binding polymorphism which is done during runtime.");
             Gadgets gd1= (Gadgets) gd;
             System.out.println("Device "+ i +": "+gd1.expensiveOrNot());
             System.out.println("b.In this type of object reference the objects point to the same location of first object and first object is casted with Gadgets.");
             System.out.println("Device "+ i +": "+gd1.batteryLife());
             System.out.println("Device "+ i +": "+gd1);
             electronic.add(gd1);
           i++  ;
         }
         else if("android device".equalsIgnoreCase(type)){
             double cost=Double.parseDouble(elec.nextLine());
             String date=elec.nextLine();
               Date year=new SimpleDateFormat("MM-dd-yyyy").parse(date);
                   String make=elec.nextLine();
                   double battery=Double.parseDouble(elec.nextLine());
                   double screen=Double.parseDouble(elec.nextLine());
                   double version=Double.parseDouble(elec.nextLine());
//                   System.out.println(version);
                 ElectronicDevices  ad =new AndroidDevices(battery,screen,cost,year,make,version);
//             System.out.println(gd.expensiveOrNot());
//            
            AndroidDevices  ad1=(AndroidDevices) ad;
             System.out.println("Device "+ i +": "+ad1.getVersionName());
             System.out.println("Device "+ i +": "+ad1.batteryLife());
             System.out.println("Device "+ i +": "+ad1.expensiveOrNot());
             System.out.println("Java does not support multiple inheritance c++ is another programming lang that supports multiple inheritance");
             System.out.println("Device "+ i +": "+ad1);
             electronic.add(ad1);
             i++;
         }
         else if("IOS device".equalsIgnoreCase(type)){
                double cost=Double.parseDouble(elec.nextLine());
             String date=elec.nextLine();
               Date year=new SimpleDateFormat("MM-dd-yyyy").parse(date);
                   String make=elec.nextLine();
                   double battery=Double.parseDouble(elec.nextLine());
                   double screen=Double.parseDouble(elec.nextLine());
                   boolean has3dtouch=Boolean.parseBoolean(elec.nextLine());
                 ElectronicDevices  ios =new IOSDevices(has3dtouch,battery,screen,cost,year,make);
//             System.out.println(gd.expensiveOrNot());
//            
            IOSDevices  ios1=(IOSDevices) ios;
             System.out.println("Device "+ i +": "+ios1.expensiveOrNot());
             System.out.println("Device "+ i +": "+ios1.getModelName());
//             System.out.println("Java does not support multiple inheritance c++ is another programming lang that supports multiple inheritance");

//System.out.println("Device "+ i +": "+ios1.expensiveOrNot());
                System.out.println("Device "+ i +": "+ios1);
             electronic.add(ios1);
             i++;
         }
         else if("household device".equalsIgnoreCase(type)){
             double cost=Double.parseDouble(elec.nextLine());
             String date=elec.nextLine();
               Date year=new SimpleDateFormat("MM-dd-yyyy").parse(date);
                   String make=elec.nextLine();
                    double watts=Double.parseDouble(elec.nextLine());
                       double length=Double.parseDouble(elec.nextLine());
                          double width=Double.parseDouble(elec.nextLine());
                             double height=Double.parseDouble(elec.nextLine());
            ElectronicDevices  hhd =new HouseholdDevices(watts,length,width,height,cost,year,make);
//             System.out.println("Device "+ i +": "+hhd.getDeviceArea());
        System.out.println("Device "+ i +": "+hhd);
             electronic.add(hhd);
             i++;
         }
         else if("oven".equalsIgnoreCase(type)){
             double cost=Double.parseDouble(elec.nextLine());
             String date=elec.nextLine();
               Date year=new SimpleDateFormat("MM-dd-yyyy").parse(date);
                   String make=elec.nextLine();
                    double watts=Double.parseDouble(elec.nextLine());
                       double length=Double.parseDouble(elec.nextLine());
                          double width=Double.parseDouble(elec.nextLine());
                             double height=Double.parseDouble(elec.nextLine());
                             String typeofdev=(elec.nextLine());
            ElectronicDevices  oven =new Oven(watts,length,width,height,cost,year,make,typeofdev);
                Oven  oven1=(Oven) oven;
                System.out.println("Device "+ i +": "+oven1.getDeviceArea());
                System.out.println("Device "+ i +": "+oven1.expensiveOrNot());
                System.out.println("Device "+ i +": "+oven1.getWatts());
                System.out.println("Device "+ i +": "+oven1.powerUsedInKWs(20));
                System.out.println("Device "+ i +": "+oven1);
                electronic.add(oven);
         i++;
         }
         else if("washing machine".equalsIgnoreCase(type)){
             double cost=Double.parseDouble(elec.nextLine());
             String date=elec.nextLine();
               Date year=new SimpleDateFormat("MM-dd-yyyy").parse(date);
                   String make=elec.nextLine();
                    double watts=Double.parseDouble(elec.nextLine());
                       double length=Double.parseDouble(elec.nextLine());
                          double width=Double.parseDouble(elec.nextLine());
                             double height=Double.parseDouble(elec.nextLine());
                             String typeofdev=(elec.nextLine());
            ElectronicDevices  wm =new WashingMachine(watts,length,width,height,cost,year,make,typeofdev);
            
                System.out.println("Device "+ i +": "+wm);
                electronic.add(wm);
                i++;
         }

}
     for(ElectronicDevices fed:electronic){
    System.out.println(fed);
     }
    }
    
}
