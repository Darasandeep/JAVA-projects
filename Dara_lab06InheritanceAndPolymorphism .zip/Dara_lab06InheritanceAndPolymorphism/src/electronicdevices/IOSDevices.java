/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package electronicdevices;

import java.util.Date;

/**
 *
 * @author Dara,Sandeep Kumar
 */
public class IOSDevices extends Gadgets{

    private final boolean has3DTouch;
    
    
    public IOSDevices(boolean has3DTouch,double battery,double screenSize,double cost,Date year,String make) {
        super(battery,screenSize,cost,year,make);
        this.has3DTouch = false;
        
    }


   public String getModelName(){
       String out;
       if(getScreenSize()>4.7)
           out="iPhone 7 Plus";
       else
           out="iPhone 7";
       return out;
   }

    @Override
    public String toString() {
        return super.toString()+" IOSDevices{" + "has3DTouch = " + has3DTouch + '}';
    }

   
    

    
}
