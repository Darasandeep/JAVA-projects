/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package electronicdevices;

import java.text.ParseException;
import java.util.Date;

/**
 *
 * @author Dara,Sandeep Kumar
 */
public class Gadgets extends ElectronicDevices {
     private double battery;
    private double screenSize;
    
    public Gadgets(double battery,double screenSize) throws ParseException{
        this.battery=battery;
        this.screenSize=screenSize;
    
}
    Gadgets(double battery, double screenSize, double cost,Date year,String make) {
        super(cost,year,make);
        this.battery=battery;
        this.screenSize=screenSize;
        
    }
    public String batteryLife(){
        String out;
       if(getBattery()>5000)
           out="Has More Battery Life";
       else
           out="Has less Battery Life";
    return out;
    }
     @Override
    public String expensiveOrNot(){
        String out;
       if(getCost()>1000)
           out="This Gadget is Expensive";
       else
           out="This Gadget is Inexpensive";
    return out;
    }

    public double getBattery() {
        return battery;
    }

    public void setBattery(double battery) {
        this.battery = battery;
    }

    public double getScreenSize() {
        return screenSize;
    }

    public void setScreenSize(double screenSize) {
        this.screenSize = screenSize;
    }

    @Override
    public String toString() {
        return super.toString()+" Gadgets{" + "battery= " + battery + ", screenSize= " + screenSize + '}';
    }

  
    
}
