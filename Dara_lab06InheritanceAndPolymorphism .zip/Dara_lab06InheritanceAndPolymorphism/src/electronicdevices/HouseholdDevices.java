/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package electronicdevices;

import java.util.Date;

/**
 *
 * @author Dara,Sandeep Kumar
 */
public class HouseholdDevices extends ElectronicDevices{
    private double watts;
    private double height;
    private double width;
    private double length;
    public HouseholdDevices(double watts,double height,double width,double length,double cost,Date year,String make) {
       super(cost,year,make);
       this.height=height;
       this.length=length;
       this.watts=watts;
       this.width=width;
    }
    @Override
    public String expensiveOrNot(){
       String out;
       if(getCost()>1500)
           out="This Household Device is Expensive";
       else
           out="Device is Inexpensive"; 
    return out;
    }
    public double getDeviceArea(){
        
    return length*width*height;
}

    public double getWatts() {
        return watts;
    }

    public void setWatts(double watts) {
        this.watts = watts;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

public double powerUsedInKWs(double hoursUsed){
    
return watts*hoursUsed/1000;
}

    @Override
    public String toString() {
        return super.toString()+" HouseholdDevices{" + "watts= " + watts + ", height= " + height + ", width= " + width + ", length= " + length + '}';
    }

  

}

