/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package electronicdevices;

import java.text.ParseException;
import java.util.Date;
import java.text.SimpleDateFormat;

/**
 *
 * @author Dara, Sandeep Kumar
 */
public class ElectronicDevices {
    private double cost;
    private Date year;
    private String make;
    
    

    public ElectronicDevices() throws ParseException {
        this.cost=0.0;
        String year="2004-Jan-01";
        SimpleDateFormat dt=new SimpleDateFormat("mm-dd-yyyy");
    Date dates=dt.parse(year);
    this.year=dates;
    }
   public ElectronicDevices(double cost,Date year,String make) {
       this.cost=cost;
       this.make=make;
       this.year=year;
   }
   public String expensiveOrNot(){
       String out;
       if(cost>500)
           out="Device is Expensive";
       else
           out="Device is Inexpensive";
   return out;
   }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public Date getYear() {
        return year;
    }

    public void setYear(Date year) {
        this.year = year;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    @Override
    public String toString() {
        return "ElectronicDevices{" + "cost= " + cost + ", year= " + year + ", make= " + make + '}';
    }

   
    }
   
    
    

