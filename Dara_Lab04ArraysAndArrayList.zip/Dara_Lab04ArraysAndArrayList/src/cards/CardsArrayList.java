/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cards;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *This is the Array list of cards through which we add or remove cards
 * @author Dara Sandeep kumar
 */
public class CardsArrayList {
    private ArrayList<Card> diamonds =new ArrayList<Card>();
    private ArrayList<Card> clubs =new ArrayList<Card>();
    private ArrayList<Card> spades =new ArrayList<Card>();
    private ArrayList<Card> hearts =new ArrayList<Card>();
   
    /**
     *This is no-argument constructor
     */
    public CardsArrayList(){
        this.clubs = clubs;
        this.diamonds = diamonds;
        this.hearts = hearts;
        this.spades = spades;
    
    }

    /**
     *This is a method that returns the ArrayList of clubs
     * @return returns the ArrayList of type clubs
     */
    public ArrayList<Card> getClubs() {
        return clubs;
    }

    /**
     *This is a method that returns the arraylist of diamonds
     * @return Returns the Arraylist of type diamonds
     */
    public ArrayList<Card> getDiamonds() {
        return diamonds;
    }

    /**
     *This is a method that returns the arraylist of hearts
     * @return Return the Arraylist of type hearts
     */
    public ArrayList<Card> getHearts() {
        return hearts;
    }

    /**
     *This is a method that returns the ArrayList of spades
     * @return Returns the ArrayList of type spades
     */
    public ArrayList<Card> getSpades() {
        return spades;
    }

    /**
     *This method is used to add the cards to the respective array list based on the card type
     * @param c card type
     * @return status of adding a card  
     */
    public String addCardsToList(Card c)
{
    switch(c.getType()){
        case "clubs" : 
          clubs.add(c);
           // System.out.println("card added successfully into clubs");
             break;
            case "diamonds" : 
            diamonds.add(c);
            //System.out.println("card added successfully into diamonds");
            break;
            case "hearts" : 
            hearts.add(c);
            //System.out.println("card added successfully into hearts");
            break;
            case "spades" : 
            spades.add(c);
            //System.out.println("card added successfully into spades");
            break;
            
            
    }
    return "card added successfully";
}

    /**
     *This method is used to remove the cards to the respective position based on the card type
     * @param position position of the card in arraylist
     * @param c Card type
     * @return  status of removing a card
     */
    public String removeCardsFromList(int position, ArrayList<Card> c)
{
    
    
        if(position <= 0 || position > c.size() ){
          return "ArrayList size underflow, card cannot be removed";
        }
        else{
            c.remove(position);
            return "Card is removed successfully!";
        }
    }
/**
     * The toString method returns the string that has the array of hearts,diamonds,clubs,spades
     * @return array of hearts,diamonds,clubs,spades.
     */
       @Override
   public String toString()
{
  String heart ="Hearts Array:["+" ";
   for(Card e : hearts){
       if(e != null)
       heart += e + " " ;
   }
   String dia = "Diamonds Array:["+" ";
   for(Card e : diamonds ){
       if(e != null)
       dia += e + " ";
   }
   String spade = "Spades Array:["+" ";
   for(Card e : spades ){
       if(e != null)
       spade += e + " ";
   }
  String club = "Clubs Array:["+" ";
   for(Card e : clubs ){
       if(e != null)
       club += e + " ";
   } 
return   " "+heart + "]  \n"  + dia + "] \n"+ spade + " ]\n"  + club + "]";
    
}
}
    
