/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cards;



/**
 *This is CardsArray class through which we can add or remove cards from array
 * @author Dara Sandeep kumar
 */
public class CardsArray {
    private Card[] clubs;
    private Card[] diamonds;
    private Card[] hearts;
    private Card[] spades;
    private final int DECK_SIZE=5;
    private int clubscount;
    private int diamondscount;
    private int spadescount;
    private int heartscount;

    /**
     *This is the no-argument constructor with the array being initialized
     */
    public CardsArray(){
     clubs=new Card[DECK_SIZE];
     diamonds=new Card[DECK_SIZE];
     hearts=new Card[DECK_SIZE];
     spades=new Card[DECK_SIZE];
     
    this.clubscount=0;
    this.diamondscount=0;
    this.heartscount =0;
    this.spadescount=0;
}

    /**
     * This is the method that returns the clubs count thats of type integer
     * @return returns the count of clubs
     */
    public int getClubscount() {
        return clubscount;
    }

    /**
    * This is the method that returns the diamonds count thats of type integer
     * @return returns the count of diamonds
     */
    public int getDiamondscount() {
        return diamondscount;
    }

    /**
     * This is the method that returns the spades count thats of type integer
     * @return returns the count of spades
     */
    public int getSpadescount() {
        return spadescount;
    }

    /**
     * This is the method that returns the hearts count thats of type integer
     * @return returns the count of hearts
     */
    public int getHeartscount() {
        return heartscount;
    }
       
    /**
     * This method call adds cards to the array
     * @param c Card details
     */
    public void addCardsToArray(Card c)
{
    
    switch(c.getType()){
        case "clubs" :
        
        if(clubscount >=0 && clubscount <DECK_SIZE)
        {
            clubs[clubscount] = c;
            clubscount++;
        }
        else{
            removeCardsFromArray(0,c.getType());
            this.addCardsToArray(c);
        }
        
        break;
        case "diamonds" :
        
        if(diamondscount >=0 && diamondscount < DECK_SIZE)
        {
            diamonds[diamondscount] = c;
            diamondscount++;
        }
        else{
            removeCardsFromArray(0,c.getType());
            this.addCardsToArray(c);
        }
        
        break;
        
        case "hearts" :
       
        if(heartscount >= 0 && heartscount < DECK_SIZE)
        {
            hearts[heartscount] = c;
            heartscount++;
            
        }
        else{
            removeCardsFromArray(0,c.getType());
            this.addCardsToArray(c);
        }
         
         break;
        
        case "spades" :
        
        if(spadescount >=0 && spadescount < DECK_SIZE)
        {
            spades[spadescount] = c;
            spadescount++;
        }
        else{
            removeCardsFromArray(0,c.getType());
            this.addCardsToArray(c);
        }
          
          break;
    }
    
}
    
    /**
     *This method call removes the cards from the array
     * @param position position of card that is to be removed 
     * @param cardType string that stores type of card
     */
    public void removeCardsFromArray(int position, String cardType)
 {
     if(cardType.equals("clubs"))
     {
       for(int i = 0; i<clubs.length-1 ; i++ ){
            
            clubs[i] = clubs[i+1];
    
     } clubscount-- ;
}   
     else if(cardType.equals("diamonds"))
     {
        
    
        for(int i = 0; i<diamonds.length-1 ; i++ ){
            
            diamonds[i] = diamonds[i+1];
    
        
     }diamondscount-- ;
}
     else if(cardType.equals("hearts"))
     {
         
        for(int i = 0; i<hearts.length-1 ; i++ ){
            
            hearts[i] = hearts[i+1];
    } heartscount-- ;
        
     
}  
     else if(cardType.equals("spades"))
     
         
    {
        for(int i = 0; i<spades.length-1 ; i++ ){
            
            spades[i] = spades[i+1];
    } spadescount-- ;
        
     }
 
}

    /**
     * The toString method returns the string that has the array of hearts,diamonds,clubs,spades
     * @return array of hearts,diamonds,clubs,spades.
     */
  
 
   @Override
   public String toString()
{
   String heart ="Hearts Array:["+" ";
   for(Card e : hearts){
       if(e != null)
       heart += e + " " ;
   }
   String dia = "Diamonds Array:["+" ";
   for(Card e : diamonds ){
       if(e != null)
       dia += e + " ";
   }
   String spade = "Spades Array:["+" ";
   for(Card e : spades ){
       if(e != null)
       spade += e + " ";
   }
  String club = "Clubs Array:["+" ";
   for(Card e : clubs ){
       if(e != null)
       club += e + " ";
   } 
return   " "+heart + "]  \n"  + dia + "] \n"+ spade + " ]\n"  + club + "]";
    
}
}
        
    
   
    
    

