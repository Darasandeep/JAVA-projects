/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cards;

/**
 *This is a Card class that gives the information about card type and card name
 * @author Dara Sandeep kumar
 */
public class Card {
    private int number;
    private String type;

    /**
     *This is an argument constructor having number and type as parameters.
     * @param number number on the card
     * @param type type of card
     */
    public Card(int number, String type){
        this.number=number;
        this.type=type; 
    }

    /**
     *This method returns the number  on the card of type integer 
     * @return the number on the card
     */
     
    public int getNumber() {
        return number;
    }

    /**
     * Sets the number on the card
     * @param number number on the card
     */
    public void setNumber(int number) {
        this.number = number;
    }

    /**
     *This method returns the type of the card of type string
     * @return type of the card
     */
    public String getType() {
        return type;
    }

    /**
     *Sets the type of the card
     * @param type type of the card
     */
    public void setType(String type) {
        this.type = type;
    }
    /** 
     * This toString method returns the number on the card of string format
     * @return the number on the card 
     */
    @Override
    public String toString() {
        return   "" +number ;
    }
    
    
}
