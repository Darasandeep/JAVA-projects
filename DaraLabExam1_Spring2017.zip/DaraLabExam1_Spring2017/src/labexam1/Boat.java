package labexam1;

/**
 * @author s528737
 */
public class Boat 

	
{
	
		
	
	private final double GAS_SFC=0.50;
	private final double GAS_FSW=6.1;
	private final double DIESEL_SFC=0.40;
	private final double DIESEL_FSW=7.2;
	private int horsePower;
	private boolean dieselPowered;
	private String name;
	
	public Boat(){
this.horsePower=0;
this.name="";
this.dieselPowered=false;

}
	public Boat(String name){
this.horsePower=0;
this.dieselPowered=false;
this.name=name;
	}
	
	public Boat(int horsePower,boolean dieselPowered,String name){
		this.horsePower=horsePower;
		this.dieselPowered=dieselPowered;
		this.name=name;
	}

	public int getHorsePower()
	{
		return horsePower;
	}

	public void setHorsePower(int horsePower)
	{
		this.horsePower = horsePower;
	}

	public boolean isDieselPowered()
	{
		return dieselPowered;
	}

	public void setDieselPowered(boolean dieselPowered)
	{
		this.dieselPowered = dieselPowered;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	@Override
	public String toString()
	{
		return "Boat{" + "horsePower=" + horsePower + ", dieselPowered=" +
			dieselPowered + ", name=" + name + '}';
	}
	
	public double computeGallonsNeeded(double hours){
		double gallonsneeded;
		String yy;
		if(dieselPowered==false){
			gallonsneeded =hours*(GAS_SFC*horsePower)/GAS_FSW;
			yy="gas";
		}
		else{
			gallonsneeded=hours*(DIESEL_SFC*horsePower)/DIESEL_FSW;
		  yy="diesel";
		}
		return gallonsneeded;
}
	public String middlePartOfName(){
		this.name=name;
		String fstring;
		int value=0;
		String[] str=name.split(" ");
		if((str.length)%2==0 ) {
			//fstring = str[1+((str.length)/2))];
			value=1+((str.length)/2);
			fstring = str[value];
			System.out.println(fstring);
		}
		else {
			//fstring = str[1+((str.length)/2))];
			value=((str.length)/2);
			fstring=str[value];
		}
		return fstring ;
	}
}
	
