package labexam1;

import java.util.Scanner;

/**
 * @author s528737
 */
public class BoatDriver 
{
    public static void main(String[] args) 
	 {
		 System.out.println("Testing the Boat class");
		 Scanner sc=new Scanner(System.in);
		 System.out.println("Enter the name of first boat");
		 String name =sc.nextLine();
		 
		 name = name.trim();
		 Boat boat1=new Boat();
		 boat1.setName(name);
		 System.out.println(boat1.toString());
		 System.out.println(" "+ +boat1.getHorsePower()+" " +boat1.isDieselPowered()+" " +boat1.getName());
		 System.out.println("Enter the horse power, whether diesel powered,name of boat 2");
		 int horsePower=sc.nextInt();
		 boolean dieselPowered=sc.nextBoolean();
		 String name1=sc.nextLine();
		 name1 = name1.trim();
		 Boat boat2=new Boat(horsePower,dieselPowered,name1);
		 boat2.setName(name1);
		 boat2.setHorsePower(horsePower);
		 boat2.setDieselPowered(dieselPowered);
		 System.out.println(boat2.toString());
		 System.out.println("How long will you be using boat2?");
		 double hours =sc.nextDouble();
		double gal = boat2.computeGallonsNeeded(hours);
		 System.out.println("boat2 will require "+ gal +" gallons of diesel for " +hours+" of use.");
		 System.out.println("middle part of boat1 is " +boat1.middlePartOfName());
		 System.out.println("middle part of boat2 is " +boat2.middlePartOfName());
		
		  System.out.println("Testing of Boat Class completed.");
		 
		 
    }
}
