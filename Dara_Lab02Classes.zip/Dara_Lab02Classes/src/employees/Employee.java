/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employees;

/**
 * This is an employee class
 * @author Dara,Sandeep Kumar
 */


public class Employee {
    private String firstName;
        private String lastName;
        private int employeeID;
        private String phoneNumber;
        private String Address;
        
   

        //5.a

    /**
     *  This is an employee class parameterized constructor with 5 arguments
     * @param firstName     FirstName of the employee
     * @param lastName      lastName of the employee
     * @param employeeID    employeeID of the employee
     * @param phoneNumber   phoneNumber of the employee
     * @param address       address of an employee
     */
        
        
        public Employee (String firstName, String lastName, int employeeID, String phoneNumber, String address){
      this.firstName =firstName ;
      this.lastName =lastName ;
      this.employeeID =employeeID ;
      this.phoneNumber =phoneNumber ;
      this.Address =address ;
             
        }

    /**
     *This is an employee class default constructor with no arguments
     */
    public Employee()
        {
        this(null,null,0,null,null);
        }
       

    /**
     *
     * @param firstName   firstName of the employee
     */
             public void setFirstName(String firstName)
            {
            this.firstName=firstName;
             }

    /**
     *
     * @return Returns the firstName of employee
     */
    public String getFirstName()
             {
                 return firstName;
             }
                   
    /**
     *
     * @param lastName  lastName of the employee
     */
    public void setLastName(String lastName)
            {
            this.lastName=lastName;
            }

    /**
     *
     * @return Returns the lastName of employee
     */
    public String getLastName()
             {
                 return lastName;
             }

    /**
     *
     * @param employeeID    employeeID of the employee
     */
    public void setEmployeeID(int employeeID)
            {
             this.employeeID=employeeID;
            }

    /**
     *
     * @return   Returns the employeeID of employee
     */
    public int getEmployeeID()
             {
                 return employeeID;
             }

    /**
     *
     * @param phoneNumber   phoneNumber of the employee
     */
    public void setPhoneNumber(String phoneNumber)
            {
            this.phoneNumber=phoneNumber;
            }

    /**
     *
     * @return       Returns the phoneNumber of employee
     */
    public String getPhoneNumber()
             {
                 return phoneNumber;
             }
            
    /**
     *
     * @param address   address of the employee 
     */
    public void setAddress(String address)
            {
            this.Address=address;
            }
           
    /**
     *
     * @return       Returns the address of employee
     */
    public String getAddress()
             {
                 return Address;
             }


    @Override //Returns a string representation of the object.
    public String toString() {
 String value = firstName+ " "+lastName+ " with  employeeID: " +employeeID+ " , phone number: " +phoneNumber+" and address: " +Address; 
                return value;
                //When we call the constructor without any values(default constructor) using object empObj02 the default values of the given variables are printed i.e., null for string and 0 for int.
    }
}

        
    
    

