/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employees;

import java.util.Scanner;

/**
 *This is EmployeeDriver class
 * @author Dara,Sandeep Kumar
 * 
 */
public class EmployeeDriver {

   
    public static void main(String args[]){
    
    // created the employee object with 4 argument constructor
Employee empObject01 = new Employee("Lousie","Adams",34562,"6602240486", "9277 Fairway Drive, Apt#208, Des Plaines, IL");
System.out.println("Employee Details01");
System.out.println("Employee ID: "+empObject01.getEmployeeID());
System.out.println("Name: " + empObject01.getFirstName() +" "+ empObject01.getLastName());
System.out.println("Address: "+empObject01.getAddress());
System.out.println("Contact Number: "+empObject01.getPhoneNumber());
System.out.println("**************************************************\n");
// created the employee object with no-argument constructor
Employee empObject02 = new Employee();
System.out.println("Employee Details02");
System.out.println("Employee ID: "+empObject02.getEmployeeID());
System.out.println("Name: " + empObject02.getFirstName() +" "+ empObject02.getLastName());
System.out.println("Address: "+ empObject02.getAddress());
System.out.println("Contact Number: "+empObject02.getPhoneNumber());
System.out.println("**************************************************\n");
// now set the value of attributes for the empObject02
empObject02.setEmployeeID(12354);
empObject02.setFirstName("Jaden");
empObject02.setLastName("Smith");
empObject02.setPhoneNumber("9494949494");
empObject02.setAddress("1231 University Drive, Apt#60, Kansas, MO");        
System.out.println("Testing toString() method of Employee class:\n"+empObject02.toString());
System.out.println("**************************************************\n");

//When we call the constructor without any values(default constructor) using object empObj02 the default values of the given variables are printed i.e., null for string and 0 for int.


        System.out.println("Testing the EmployeeSalary class:");
     
Scanner sc=new Scanner(System.in);
    System.out.print("Enter the hourly pay rate of the Employee : $");
     double hourlyRate=sc.nextDouble();
     System.out.print("Enter the insurance rate of the Employee in percentage:");
     double insuranceRate=sc.nextDouble();
     System.out.print("Enter the tax rate of the Employee in percentage:");
     double taxRate=sc.nextDouble();
     System.out.print("Enter the bonus amount:$ ");
     double Bonus=sc.nextDouble();
     EmployeeSalary EmployeeSalaryobj1=new EmployeeSalary();
     EmployeeSalary EmployeeSalaryobj2=new EmployeeSalary();
     EmployeeSalaryobj1.sethourlyRate(hourlyRate);
     EmployeeSalaryobj1.setinsuranceRate(insuranceRate);
     EmployeeSalaryobj1.settaxRate(taxRate);
     EmployeeSalaryobj1.setBonus(Bonus);
     System.out.println("**************************************************\n");
        System.out.println("Testing the tostring() method of EmployeeSalary class :  \n"+EmployeeSalaryobj1.toString());
       System.out.println("**************************************************\n");
        System.out.println("The details of the EmployeeSalaryObj2 are as follows:\nTesting the toString() method of EmployeeSalary class :\n"+EmployeeSalaryobj2.toString());
       System.out.println("**************************************************\n"); 
    EmployeeSalaryobj2.sethourlyRate(56.72);
     EmployeeSalaryobj2.setinsuranceRate(18.40);
     EmployeeSalaryobj2.settaxRate(9.65);
     EmployeeSalaryobj2.setBonus(8463.77);
     System.out.println("Testing the toString() method of EmployeeSalary class :  \n "+EmployeeSalaryobj2.toString());
     
     
    
        
    }
}
