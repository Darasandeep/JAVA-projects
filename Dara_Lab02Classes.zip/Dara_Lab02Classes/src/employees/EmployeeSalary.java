/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employees;


/**
 *this is an EmployeeSalary class
 * @author Dara,Sandeep Kumar 
 * 
 * 
 */
public class EmployeeSalary {
   private double hourlyRate;          
   private double Bonus;                               
   private double insuranceRate;         
   private double taxRate;             
   private int HOURS =30;                 
    
    /**
     *
     * @param hourlyRate    hourly pay rate of the employee
     * @param bonus         annual bonus of the employee
     * @param insuranceRate  insurance deduction percentage of the employee
     * @param taxRate        tax percentage of the employee
     * Here EmployeeSalary is an parameterized constructor with four attributes in EmployeeSalary class
     */
   
   
    public EmployeeSalary(double hourlyRate, double bonus, double insuranceRate, double taxRate){
    this.hourlyRate=hourlyRate;
    this.Bonus =bonus;
    this.insuranceRate=insuranceRate;
    this.taxRate=taxRate;
    }

    /**
     *EmployeeSalary is an default constructor without any attributes in EmployeeSalary class
     */
    public EmployeeSalary(){
   this(0.0d,0.0d,0.0d,0.0d);
    }

   

    /**
     *
     * @return     This method returns the value of hourlyRate
     */
    public double gethourlyRate() {
        return hourlyRate;    
}
     /**
     *
     * @param hourlyRate hourly pay rate of the employee 
     */
    public void sethourlyRate(double hourlyRate) {
        this.hourlyRate = hourlyRate;
     }

    /**
     *
     * @return    This method returns the value of Bonus
     */
    public double getBonus() {
        return Bonus;
    }
    
    /**
     *
     * @param Bonus   annual bonus of the employee 
     */
    public void setBonus(double Bonus) {
        this.Bonus = Bonus;
    }

    /**
     *
     * @return This method returns the value of insuranceRate
     */
    public double getinsuranceRate() {
        return insuranceRate;
    }

    /**
     *
     * @param insuranceRate  insuranceRate of the employee 
     */
    public void setinsuranceRate(double insuranceRate) {
        this.insuranceRate = insuranceRate;
    }

    /**
     *
     * @return      This method returns the value of taxRate
     */
    public double gettaxRate() {
        return taxRate;
    }

    /**
     *
     * @param taxRate  taxRate of the employee 
     */
    public void settaxRate(double taxRate) {
        this.taxRate = taxRate;
    }

    /**
     *
     * @return  This method returns the value of number of HOURS
     */
    public int getHOURS() {
        return HOURS;
    }

    /**
     *
     * @param HOURS  number of HOURS employee works 
     */
    public void setHOURS(int HOURS) {
        this.HOURS = HOURS;
    }

//12.b)

    /**
     *
     * @return  This method is used to calculate and return the value of monthlySalary of an employee
     */
    public double monthlySalary(){
       
        double monthlysalary = hourlyRate*4*HOURS;

    return monthlysalary;
    }

    /**
     *
     * @return       This method is used to calculate and return the monthlyInsurance of an employee
     */
    public double monthlyInsurance(){
        double monthlysalary = hourlyRate*4*HOURS;
        
        
          return monthlysalary*(insuranceRate/100);
    }
    
    /**
     *
     * @return      This method is used to calculate and return the value of annualGrossSalary of an employee
     */
    public double annualGrossSalary(){
        double monthlysalary = hourlyRate*4*HOURS;
       double annualgrosssalary =((monthlysalary)*12)+Bonus;
     return (annualgrosssalary); 
          
    }
    
    /**
     *
     * @return      This method is used to calculate and return the value of annualNetPay of an employee
     */
    
    public double annualNetPay(){
        double monthlysalary = hourlyRate*4*HOURS;
        double annualgrosssalary =((monthlysalary)*12)+Bonus;
        
        double annualsalary = (monthlysalary)*12;
        
        double misc= (3.2/100); 
    
     
    double    annualnetpay =annualgrosssalary-(annualgrosssalary*(taxRate/100))-(monthlysalary)*12*(insuranceRate/100)-(annualgrosssalary*3.2/100);
     return annualnetpay;
    }

    
   @Override //Returns a string representation of the object.
    public String toString() {
        return  "Hourly pay rate:$" + hourlyRate +  ", insurance rate:" + insuranceRate + "%, tax:" + taxRate+ "%, annual bonus:$" + Bonus + ", Hours per week: " + HOURS +
                "\nThe monthly salary of the Employee is:$"+monthlySalary()+ "\nThe monthly insurance of the Employee is:$" +monthlyInsurance()+
                "\nThe annual gross salary of the Employee is:$" +annualGrossSalary()+ "\nThe gross annual net pay of the Employee is:$"+annualNetPay();
    }
    
    
    
}
