package labexam2;

/**
 * @author Dara,Sandeep kumar
 */
public class Teacher extends Person
{
private int numCourses;
private String courses[];
private int MAX_courses=5;

	public Teacher(String name, String address)
	{
		super(name, address);
		this.numCourses=0;
		courses=new String[MAX_courses];
		
	
	}

	@Override
	public String toString()
	{
		return "Teacher:" +super.toString();
	}
	
public boolean addCourse(String course){
//	System.out.println("course"+course);
	boolean x=false;
//	courses[0]="";
//	courses[1]="";
	for(int i=0;i<3;i++){
            System.out.println(courses[i]);
		if(courses[i].equalsIgnoreCase(course)){
			x=false;
		}
		else{
			courses[i]=course;
			x=true;
			numCourses+=1;
		}	
//	           System.out.println(x);
        }
return x;
}

//			for(String x:courses ){
//		if(course.equals(x)){
//		}
//		else{
//			courses()
public boolean removeCourse(String course){
	boolean x;
for(int i=0;i<courses.length-1;i++){
		if(course.equalsIgnoreCase(courses[i])){
			courses[i]=null;
			courses[i+1]=courses[i];
			numCourses-=1;
			x=true;
			
		}
		else{
			x=false;
		}	
	}
		return false;
}
	
}


	


//}
