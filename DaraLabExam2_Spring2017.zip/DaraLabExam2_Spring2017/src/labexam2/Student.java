package labexam2;

import java.util.ArrayList;

/**
 * @author Dara,sandeep kumar
 */
public class Student extends Person 
{
private int numCourses;
private ArrayList <String> courses;
private ArrayList <Integer> grades;
private final int MAX_COURSES=30;

	public Student(String name,String address)
	{
		super(name, address);
		this.numCourses=0;
		courses=new ArrayList<String>();
		grades=new ArrayList<Integer>();
	}

	@Override
	public String toString()
	{
		return "Student:" +super.toString() ;
	}
	public void addCourseGrade(String course,int grade){
		courses.add(course);
		grades.add(grade);
		numCourses+=1;
		
	}
	public void printGrades(){
		for(String temp:courses){
			System.out.print(" "+temp+":");
			for(int temp1:grades){
			System.out.print(" "+temp1+" ");
		}	
	}
	}
	
	public double getAverageGrade(){
		double avg=0.0;
		
for(double temp1:grades){
	avg=avg+(temp1)/2;
					
			
		}
	return avg;
}

	
}

