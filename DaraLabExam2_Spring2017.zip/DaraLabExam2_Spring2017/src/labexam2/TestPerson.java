package labexam2;

/**
 * @author Dara,Sandeep kumar
 */
public class TestPerson 
{
    public static void main(String[] args) 
	 {
        Student s1=new Student("Bill Gates","1 Happy Ave");
		  s1.addCourseGrade("CS101", 97);
		  s1.addCourseGrade("CS102", 68);
		  System.out.print(s1.toString());
		  s1.printGrades();		  
		  System.out.println("\nAverage is"+s1.getAverageGrade());
		  Teacher t1=new Teacher("Ada Lovelace","8 Sunset Way");
		  System.out.println(t1.toString());
		  String[] courses=new String[3];
		  courses[0]="cs101";
		  courses[1]="cs102";
		  courses[2]="cs101";
		  // i have tried to call the function using loop but i am unable to find out where there is an null pointer exception using the logic of loops. 
		  for(int i=0;i<courses.length;i++){

			  if(t1.addCourse(courses[i])== true){
				  System.out.println(courses[i]+"added");  
			  }
			  else{
				  System.out.println(courses[i]+"cannot be added");
			  }
			  
		  }
		  for(int i=0;i<courses.length;i++){
			  if(t1.removeCourse(courses[i])== true){
				  System.out.println(courses[i]+"removed");
				  
			  }
			  else{
				  System.out.println(courses[i]+"cannot be removed");
			  }
			  
		  }
    }
}
