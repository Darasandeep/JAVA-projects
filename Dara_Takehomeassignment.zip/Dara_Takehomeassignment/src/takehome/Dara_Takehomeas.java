
package takehome;


import java.io.FileNotFoundException;


/**
* I certify that all code in this file is my own work.
* This code is submitted as the solution to Assignment 1
* in CSIS44542 Object-Oriented Programming, 2017, section 01
* Due date: 5pm, Friday, February 16, 2017.
* this is my class.
* @author Dara,Sandeep kumar
*/
public class Dara_Takehomeas  {

    private double fleschreadingease;
    private double fleschgradelevel;
   private double syllablecount;
  private double wordscount;
   private double sentencecount;
   String schoollevel;
    
    /**
     *This method calculates the number of syllables in a given paragraph
     * @param paragraph Paragraph that is given as input
     * @throws FileNotFoundException throws exception if file is not found
     */ 
    public void calcuSyllable(String paragraph) throws FileNotFoundException{
     int syllable = 0;
     
  //splits the paragraph into sentences and replaces the . with empty space   
String [] sent=paragraph.split("[!?.:]+");
 paragraph = paragraph.replace("."," ");


//splitting the String and storing as an array        
String[] s= paragraph.split(" ");
      
       int words=s.length;
 // loop for iterating the words in araay ofsplit method
        for(int i =0; i< s.length;i++)
        {
 
         s[i] = s[i].toLowerCase(); 
           
       s[i] = s[i].trim();
     if(s[i].length() == 1){
     
          syllable++;
            }
            else{
                //loop for comparing each letter in each word
                
                for(int k=0;k<s[i].length();k++){    
                //comparing each letter with vowels        
                         String letter = Character.toString((s[i].charAt(k)));
 if(letter.equals("a") || letter.equals("e") || letter.equals("i")|| letter.equals("o") || letter.equals("u")||letter.equals("y")){
  {
    syllable++;
    //condition to check whether next letter is vowel or not
      if(k+1 <= s[i].length()-1 ){
            String letter1 = Character.toString((s[i].charAt(k+1)));
 if(letter1.equals("a") || letter1.equals("e") || letter1.equals("i")|| letter1.equals("o") || letter1.equals("u")||letter1.equals("y")){
 //if next letter is vowel then we doesnt increment the syllable
     k++;
     //if last letter of word is e then decrementing the syllable
 if(s[i].lastIndexOf("e")==s[i].length()-1){
    syllable--;
      }
   }
       }                       
    }
        }
    }            
        }           
    }                   
     sentencecount=sent.length;  
     wordscount=words;  
    syllablecount=syllable;
   
    }
    /**
     * this method calculates the fleschreadinglevel of paragraph
     * @return fleschreadinglevel of the paragraph
     */
    public double fleschreadinglevel(){
//        System.out.println(syllablecount);
      fleschreadingease = 206.8350-1.0150*(wordscount/sentencecount)-84.6*(syllablecount/wordscount);
       if(fleschreadingease>90.0 && fleschreadingease<=100.0){
           String Schoollevel= "5thgrade";
           this.schoollevel=Schoollevel;
         
     }
       else if(fleschreadingease>80.0 && fleschreadingease<=90.0){
           String Schoollevel="6thgrade";
           this.schoollevel=Schoollevel;
         
     }
       else if(fleschreadingease>70.0 && fleschreadingease<=80.0){
           String Schoollevel="7thgrade";
           this.schoollevel=Schoollevel;
         
     } 
       else if(fleschreadingease>60.0 && fleschreadingease<=70.0){
           String Schoollevel="7thgrade";
           this.schoollevel=Schoollevel;
         
     } 
       else if(fleschreadingease>50.0 && fleschreadingease<=60.0){
           String Schoollevel="8&9thgrade";
           this.schoollevel=Schoollevel;
         
     } 
       else if(fleschreadingease>40.0 && fleschreadingease<=50.0){
           String Schoollevel="10th to 12thgrade";
           this.schoollevel=Schoollevel;
         
     }
       else if(fleschreadingease>30.0 && fleschreadingease<=40.0){
           String Schoollevel="College";
           this.schoollevel=Schoollevel;
         
     }    else if(fleschreadingease>0.0 && fleschreadingease<=30.0){
           String Schoollevel="college graduate";
           this.schoollevel=Schoollevel;
         
     } 
      
      return fleschreadingease;
    }

    /**
     *this method calculates the fleschkinkaidgrade of the given paragraph
     * @return returns the fleschkinkaidgrade of paragraph
     */
    public double fleschkinkaidgrade(){
      fleschgradelevel = 0.39*(wordscount/sentencecount)+11.8*(syllablecount/wordscount)-15.59;
     return fleschgradelevel;

    }
  
    }

    

    


    
    


