/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package takehome;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
*I certify that all code in this file is my own work.
* This code is submitted as the solution to Assignment 1
* in CSIS44542 Object-Oriented Programming, 2017, section 01
* Due date: 5pm, Friday, February 16, 2017.
* @author Dara Sandeep Kumar
*/
public class Driver {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException throws exception if file is not found
     */
    public static void main(String[] args) throws FileNotFoundException {
         Scanner console =new Scanner(System.in); 
      System.out.print("Please enter the name of the file containing ths passage of text:");
      String inputfilename=console.nextLine();
      File inputfile =new File(inputfilename);
      
      if(inputfile.exists()){
      Scanner in = new Scanner(inputfile);
//     

         String paragraph=in.nextLine();
         
        
         Dara_Takehomeas th=new Dara_Takehomeas();
            th.calcuSyllable(paragraph);
            System.out.println("The passage has the following scores:-");
            System.out.print("Flesch reading ease: ");
            System.out.printf("%.1f",th.fleschreadinglevel());
            System.out.print("("+th.schoollevel+")");
            System.out.print("\nFlesch-Kincaid grade level:");
            System.out.printf("%.1f\n",th.fleschkinkaidgrade());
  
}
        else{
                System.out.println("File not found.");
                }
}
}

    