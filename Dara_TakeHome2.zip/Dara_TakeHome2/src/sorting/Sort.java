/**
 * I certify that all code in this file is my own work.
 * This code is submitted as the solution to Assignment 2
 * in CSIS44542 Object-Oriented Programming, 2017, section 01
 * Due date: 5pm, Friday, March 17, 2017.* To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sorting;

import java.util.ArrayList;
import java.util.Arrays;


 /**
  * This is sort class 
  * @author Dara,Sandeep Kumar 
  */
public class Sort {
 
    /**
     *This method sorts the elements of array using selection sort technique 
     * @param array Array of integers that should be sorted
     */
    public  void selectionSort(int[] array){ 
        int count=0;
//      selecting elements in array
        for (int i = 0; i < array.length - 1; i++)  
        {  
            int index = i;  
//            comparing with next element
            for (int j = i + 1; j < array.length; j++){
                
                if (array[j] < array[index]){  
//      finding smallest number in array
                    index = j;
                    count++;
                }  
            }  

            int small = array[index];
//            Swaping the numbers in array
            array[index] = array[i];  
            array[i] = small;  
        }  
//        printing number of swaps
        System.out.print("no of swaps:"+count);
    }  

    /**
     *This method sorts the elements of array using insertion sort technique 
     * @param array Array of integers that should be sorted
     */
   public void insertionSort(int[] array){
    int n = array.length;
    int swap = 0;
//      selecting elements in array
    for (int c = 1; c < n; c++){
        int vari = array[c];
        //       selecting next element in array  
        for (int d = c - 1; d > 0 && vari < array[d]; d--) {
 //          swapping number if first number is less than second number and comparing with the group  
            array[d+1] = array[d];
            array[d+1] = vari;
          
            swap++;

        }
    }
      
        System.out.print("no of swaps:"+swap);
   }
   
   
    
  
    /**
     *This method sorts the elements of array using bubble sort technique 
     * @param array Array of integers that should be sorted
     */
    public void bubbleSort(int[] array) {  
        int swap;  
        int count=0;
        int arr = array.length; 
//      selecting elements in array
         for(int i=0; i < arr; i++){  
//       selecting next element in array     
                 for(int j=1; j < (arr-i); j++){  
                          if(array[j-1] > array[j]){  
//          swapping number if first number is less than second number                              
                             swap = array[j-1];  
                                 array[j-1] = array[j];  
                                array[j] = swap;  
                                count++;
                         }  
                          
                 }
         }
//           printing number of swaps 
         System.out.print("no of swaps:"+count);  
       
       } 
    
}
