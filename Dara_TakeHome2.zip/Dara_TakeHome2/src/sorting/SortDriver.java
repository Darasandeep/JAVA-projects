
/** I certify that all code in this file is my own work.
 * This code is submitted as the solution to Assignment 2
 * in CSIS44542 Object-Oriented Programming, 2017, section 01
 * Due date: 5pm, Friday, March 17, 2017.* To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sorting;

import java.util.Arrays;

/**
 * This is Driver class
 * @author Dara,Sandeep Kumar
 * 
 */
public class SortDriver {

    /**
     * This is main method
     * @param args the command line arguments
     * 
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Sort obj=new Sort();
         int[] testarray;    
        int[] orderedNum=new int[1000];
//        populating the array with numbers 1 to1000
        for(int i=0;i<orderedNum.length;i++){
            orderedNum[i]=i+1;
        }
          System.out.println("Array of ordered numbers: ");  
        System.out.println(Arrays.toString(orderedNum));
//         populating the array with numbers 1000 to 1
        int[] revnum=new int[1000];
        for(int i=0;i<revnum.length;i++){
            revnum[i]=revnum.length-i;
        } 
            System.out.println("Array of reverse numbers: ");  
       System.out.println(Arrays.toString(revnum));
//       populating the array with random numbers       
          int[] randomnum=new int[1000]; 
        for(int i = 0; i < randomnum.length; i++) {
      randomnum[i] = (int)(Math.random()*1000);
        }
//        printing the array
        System.out.println("Array of random numbers: "); 
        System.out.println(Arrays.toString(randomnum));
        System.out.println("____________________________________________________________________________________");
//       Sorting the numbers which are in order 1-1000 
        System.out.println("Testing for numbers in order:");
//        cloning the original array into testarray and calling the methods  
        testarray = orderedNum.clone();
        System.out.print("Selectionsort:     ");
//        Storing the start time before sorting is done
        long timeBeforerevsel=System.currentTimeMillis();
        obj.selectionSort(testarray);
//        Storing the time after sorting is done
        long timeAfterrevsel=System.currentTimeMillis();
//        calculating time taken for sorting
        System.out.println("\ttime: "+(timeAfterrevsel-timeBeforerevsel ));
        testarray = orderedNum.clone();
        System.out.print("Insertionsort:     ");
        long timeBeforerevins=System.currentTimeMillis();
        obj.insertionSort(testarray);
        long timeAfterrevins=System.currentTimeMillis();
        System.out.println("\ttime: "+(timeAfterrevins-timeBeforerevins ));
        testarray = orderedNum.clone();
        System.out.print("Bubblesort:        ");
        long timeBeforerevbub=System.currentTimeMillis();
        obj.bubbleSort(testarray);
        long timeAfterrevbub=System.currentTimeMillis();
        System.out.println("\ttime: "+(timeAfterrevbub-timeBeforerevbub ));
        System.out.println("*********************************************************");
//    Sorting the numbers which are in Reverse order 
         System.out.println("Testing for numbers in Reverse order:");
//         cloning the original array into testarray and calling the methods  
        testarray = revnum.clone();
        System.out.print("Selectionsort:     ");
//          Storing the start time before sorting is done
        long timeBeforeordersel=System.currentTimeMillis();
        obj.selectionSort(testarray);
//        Storing the time after sorting is done
        long timeAfterordersel=System.currentTimeMillis();
//              calculating time taken for sorting
        System.out.println("\ttime: "+(timeAfterordersel-timeBeforeordersel ));
        testarray = revnum.clone();
        System.out.print("Insertionsort:     ");
        long timeBeforeorderins=System.currentTimeMillis();
        obj.insertionSort(testarray);
        long timeAfterorderins=System.currentTimeMillis();
        System.out.println("\ttime: "+(timeAfterorderins-timeBeforeorderins ));
        testarray = revnum.clone();
        System.out.print("Bubblesort:        ");
        long timeBeforeorderbub=System.currentTimeMillis();
        obj.bubbleSort(testarray);
        long timeAfterorderbub=System.currentTimeMillis();
        System.out.println("\ttime: "+(timeAfterorderbub-timeBeforeorderbub ));
        System.out.println("*********************************************************");
//        Sorting the numbers which are generated randomly      
       System.out.println("Testing for Random numbers:");
//       cloning the original array into testarray and calling the methods  
        testarray = randomnum.clone();
        System.out.print("Selectionsort:     ");
//        Storing the start time before sorting is done
        long timeBeforerandsel=System.currentTimeMillis();
        obj.selectionSort(testarray);
//        Storing the time after sorting is done
        long timeAfterrandsel=System.currentTimeMillis();
//        calculating time taken for sorting
        System.out.println("\ttime: "+(timeAfterrandsel-timeBeforerandsel ));
        testarray = randomnum.clone();
        System.out.print("Insertionsort:     ");
        long timeBeforerandins=System.currentTimeMillis();
        obj.insertionSort(testarray);
        long timeAfterrandins=System.currentTimeMillis();
        System.out.println("\ttime: "+(timeAfterrandins-timeBeforerandins ));
        testarray = randomnum.clone();
        System.out.print("Bubblesort:        ");
        long timeBeforerandbub=System.currentTimeMillis();
        obj.bubbleSort(testarray);
        long timeAfterrandbub=System.currentTimeMillis();
        
        System.out.println("\ttime: "+(timeAfterrandbub-timeBeforerandbub ));
        System.out.println("*********************************************************");
        }
}
