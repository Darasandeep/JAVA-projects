/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital;

import java.util.Date;

/**
 *
 * @author Dara,sandeep kumar
 */
public class Patient {
    private int age;
    private String fname;
    private char gender;
    private int insuranceId;
    private Date lastCheckUpDate;
    private boolean lastCheckUpStatus;
    private String lastDoctorVisited;
    private String lName;

    public Patient(int age, String fname, char gender, int insuranceId, Date lastCheckUpDate, boolean lastCheckUpStatus, String lastDoctorVisited, String lName) {
        this.age = age;
        this.fname = fname;
        this.gender = gender;
        this.insuranceId = insuranceId;
        this.lastCheckUpDate = lastCheckUpDate;
        this.lastCheckUpStatus = lastCheckUpStatus;
        this.lastDoctorVisited = lastDoctorVisited;
        this.lName = lName;
    }

    public Patient() {
        
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    public int getInsuranceId() {
        return insuranceId;
    }

    public void setInsuranceId(int insuranceId) {
        this.insuranceId = insuranceId;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }
    
     public String getLastCheckUpDetails() {
        if(lastCheckUpStatus==true){
            return "Last Check Up Date: "+lastCheckUpDate + "Last Doctor Visited: "+lastDoctorVisited+"Last Check Up Status: "+"Success";
        }
            else{
            return "Last Check Up Date:"+lastCheckUpDate + "Last Doctor Visited: "+lastDoctorVisited+"Last Check Up Status: "+"Failure";
                    }
        }

    @Override
    public String toString() {
        return   "\nFirst Name: " + fname + "\nLast Name: "+ lName+ "\nInsurance ID: "+ insuranceId  + "\nAge: " + age+"\nGender: "+gender  ;
    }
     
    }
    

