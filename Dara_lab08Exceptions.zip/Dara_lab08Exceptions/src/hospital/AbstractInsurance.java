/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Dara,sandeep kumar
 */
public abstract class AbstractInsurance extends Patient implements Insurance {

    
    private String InsuranceCompanyName;
    private double InsuranceCoverage;

    public AbstractInsurance(String InsuranceCompanyName, double InsuranceCoverage, int age, String fname, char gender, int insuranceId, Date lastCheckUpDate, boolean lastCheckUpStatus, String lastDoctorVisited, String lName) {
        super(age, fname, gender, insuranceId, lastCheckUpDate, lastCheckUpStatus, lastDoctorVisited, lName);
        this.InsuranceCompanyName = InsuranceCompanyName;
        this.InsuranceCoverage = InsuranceCoverage;
    }
    

    @Override
    public abstract double calcAmountPayableToHospital(double PremiumPaid, double billGenerated) throws NegativeAmountException; 
     

    @Override
    public String checkHealthInsurancePlan() throws InvalidInsuranceIDException{
      if(getInsuranceId()>0&&getInsuranceId()<10000)
          return "Health maintenance organizations (HMOs) plan";
      else if(getInsuranceId()>=10000&&getInsuranceId()<20000)
          return "Preferred provider organizations (PPOs) plan";
      else if(getInsuranceId()>=20000&&getInsuranceId()<30000)
              return "Point-of-service (POS) plan";
      else if(getInsuranceId()>=30000&&getInsuranceId()<40000)
           return "High-deductible health plans (HDHPs)";
      else
          throw new InvalidInsuranceIDException("invalid insurance id is passed");
    }

    public String getInsuranceCompanyName() {
        return InsuranceCompanyName;
    }

    public double getInsuranceCoverage() {
        return InsuranceCoverage;
    }

    @Override
    public String toString() {
        return  "Insurance Company Name: " + InsuranceCompanyName + "Insurance Coverage: " + InsuranceCoverage ;
    }
    
}
