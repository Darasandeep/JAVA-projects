/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital;

import java.util.Date;
import java.util.List;

/**
 *
 * @author Dara,sandeep kumar
 */
public class MaternityWard extends AbstractHospitalInfo{
    private boolean appointmentStatus;

    public MaternityWard(String hospitalName, String hospitalAddress, int age, String fname, char gender, int insuranceId, Date lastCheckUpDate, boolean lastCheckUpStatus, String lastDoctorVisited, String lName) {
        super(hospitalName, hospitalAddress, age, fname, gender, insuranceId, lastCheckUpDate, lastCheckUpStatus, lastDoctorVisited, lName);
    }
    
    
    @Override
    public double calcBill(String billingDetails) {
      double bill=0.0;
      String []item=billingDetails.split(",");
      for(String i:item){
      if(i!=null)
           if(i.equalsIgnoreCase("group B streptococcus"))
           {
               bill += 18.75;
           }
         else  if(i.equalsIgnoreCase("respiratory syncytial virus"))
           {
               bill += 21.29;
           }
         else  if(i.equalsIgnoreCase("influenza"))
           {
               bill += 18.98;
           }
         else  if(i.equalsIgnoreCase("pertussis"))
           {
               bill += 17.5;
           }
           else{
                bill = bill+ EMERGENCY_FEE;
           }
       }
       
       
 
    
      return bill+BASE_CONSULTATION_FEE;
    }
    @Override
    public void assignDocToPatient(List<Doctor> doctorList) throws SpecialistNotFoundException{
    for(Doctor temp:doctorList)  {
        if(appointmentStatus==true&&temp.getSpecialityType().equalsIgnoreCase("Gynaecologist")){
            appointmentStatus=true;
            String doctname=temp.getName();
            String patientname=getFname()+":"+getlName();
            getDoctorsMappedToPatients().add(doctname+":"+patientname);
            getAvailableDoctorsList().remove(doctname);
    }
    
}
    }

    @Override
    public String toString() {
        return   super.toString()+"\nStatus=" + appointmentStatus;
    }
    
}
