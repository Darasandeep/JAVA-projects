/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

/**
 * 
 *Application launches from this class
 * @author Dara,Sandeep kumar
 */
public class HospitalDriver {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException Throws if file is not found
     * @throws java.text.ParseException Parse the exception if there parsing has
     * problems
     */
    public static void main(String[] args) throws FileNotFoundException, ParseException,  InvalidInsuranceIDException {
        // TODO code application logic here
	
	//1. Declare and initialize a scanner object "sc" to read from the file "input.txt"
        Scanner sc = new Scanner(new File("Input.txt"));

        //2. Create an object for List of doctors with variable name as doctors list and initialize it with arraylist.
        // Declare variable count of type int and declare it to a value of 0. Also declare variables docname, SpecialityType, officeHours of type String.
        // Create an object for AbstarctHospitalInfo with variable name as hospitalInfo and initialize it with ChildWard class.
        List<Doctor> doctorsList = new ArrayList<>();
        int count = 0;
        String docname;
        String SpecialityType;
        String officeHours;
        AbstractHospitalInfo hospitalInfo = new ChildWard();
        
        //3. while input.txt has more data(While loop starts here) {
        //  If the Passed type is "Doctor" then, Read in the data, and store them to the respective variables such as,
        //  docname, specialityType, officeHours. Initlaize the multiple argument contructor of Doctor class with the mentioned variables.
        //  Using a try , catch block add the the doctor to the hospitalInfo. 
        //  3a. Else scan the next line and store the data into genderstring variable. Now declare a variable gender of type char and store the character at
        //      0th position in the genderstring to the ageString variable. Store this age into a variable age of type int. Now among this stored age, if the age is less than 16
        //      scan the details of hospital and store them accordingly into  hospitalName, hospitalAddress, childFName, childLName of type String, 
        //      insuranceID of type int, lastdateString of type String.
        //      Now declare DateFormat class and initialize it to simpleDateFormat class of format "MM/dd/yyy" . Declare a varialbe of type Date and variable name as 
        //      lastCheckUpDate and parse the lastDateString. Declare a variable lastCheckUpStatusString of type String and scan the data.
        //      Declare a variable lastCheckUpStatus of type boolean. If the status is "true" is equal to status of lastCheckUpStatusString(HINT: Use .equals),
        //      then declare a variable lastDoctorVisited of type String and scan the data.
        
        while(sc.hasNext()){
            String doc = sc.nextLine();
           // System.out.println(doc);
            if(doc.equals("Doctor")){
                docname = sc.nextLine();
                //System.out.println(docname);
                SpecialityType = sc.nextLine();
               // System.out.println(SpecialityType);
                officeHours = sc.nextLine();
               // System.out.println(officeHours);
                Doctor d = new Doctor(docname,SpecialityType,officeHours); 
                try
                {
                    hospitalInfo.addDoctors(d);
                }
                catch(InvalidDoctorSizeException e)
                {
                    System.out.println(e.getMessage());
                }
            }
                else
                {
                        String genderstring = sc.nextLine();
                        //System.out.println(genderstring);
                        char gender= genderstring.charAt(count);
                        //System.out.println(gender);
                        int age = Integer.parseInt(sc.nextLine());
                        //System.out.println(age);
                        if(age<16)
                        {
                            String hospitalName = sc.nextLine();
                            //System.out.println(hospitalName);
                            String hospitalAddress=sc.nextLine();
                           //System.out.println(hospitalAddress);
                            String childFName = sc.nextLine();
                            //System.out.println(childFName);
                            String childLName = sc.nextLine();
                            int insuranceID = Integer.parseInt(sc.nextLine());
                            //System.out.println(insuranceID);
                            String lastdateString = sc.nextLine();
                            DateFormat d = new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
                            Date lastCheckUpDate = d.parse(lastdateString);
                            String lastCheckUpStatusString = sc.nextLine();
                            boolean lastCheckUpStatus = Boolean.parseBoolean(lastCheckUpStatusString);
                            if("true".equalsIgnoreCase(lastCheckUpStatusString))
                            {
                                String lastDoctorVisited = sc.nextLine();
                                
                                //  3a(i) Create an object for ChildWard class with variable name as childWard and initialize the multiple argument contructor of ChildWard Class.
                    //        Test the toString method of child ward class. Using try catch block assign the doctor to the patient from the available doctors list in the hospital info to the patient in child ward.
	//    Create a variable billingDetails of type String and scan the data, also create a variable childBillGenerated of type double and invoke the calculate bill method
                    //    of childward using the scanned billing details. Print the last check updetails of the patient in child ward.             
	//    Create a variable InsuranceCompany of type String and scan the data, also create a variable  InsuranceCoverage of type double and parse the data
	// 3a(ii)  Now create an object for ChildInsurance of variable name childInsurance and invoke multiple argument contructor of childInsurance class.
                    //         Test the toString method of child insurance class. Using try catch block invoke the chekcHealthInsurancePlan in childinsurance class and store the returned value in
                    //         inusrancePlanName variable of type String,create a variable premiumPaid of type double and scan the data. Now using one more try catch block
                    //         invoke the calcAmountPayableToHospital method of child insurance class and store the returned value in amountPayable variable of type double.
                                ChildWard childWard = new ChildWard(hospitalName,hospitalAddress,age, childFName,gender,insuranceID,lastCheckUpDate ,lastCheckUpStatus,lastDoctorVisited,childLName);
                                System.out.println("****************************************\nPatient Details: ");
                                System.out.println("****************************************");
                                System.out.println("Child Ward Deatils: "+childWard.toString());
                                
                                

                                try{
                                    childWard.assignDocToPatient(hospitalInfo.getAvailableDoctorsList());
                                    throw new SpecialistNotFoundException("There is no available doctors in the list who are child specialist ");
                                }
                                catch(SpecialistNotFoundException s)
                                {
                                    System.out.println("ChildSpecialistDoctorNotFoundException: "+s.getMessage());
                                }
                                
                                String billingDetails = sc.nextLine();
                                double childBillGenerated=childWard.calcBill(billingDetails);
                                System.out.println("Bill Amount Generated for Children before Indsurance deduction:"+childBillGenerated);
                                System.out.println(childWard.getLastCheckUpDetails());
                                
                                String InsuranceCompany = sc.nextLine();
                                double InsuranceCoverage = Double.parseDouble(sc.nextLine());
                                ChildInsurance childInsurance = new ChildInsurance( InsuranceCompany, InsuranceCoverage,age, childFName, gender, insuranceID, lastCheckUpDate, lastCheckUpStatus, lastDoctorVisited, childLName);
                                System.out.println(childInsurance.toString());
                                try
                                {
                                    String insurancePlanName= childInsurance.checkHealthInsurancePlan();
                                    System.out.println("Insurance Plan Name: "+insurancePlanName);
                                }
                                catch(InvalidInsuranceIDException i)
                                        {
                                            System.out.println(i.getMessage());
                                        }
                                double premiumPaid = Double.parseDouble(sc.nextLine());
                                try
                                {
                                   double amountPayable= childInsurance.calcAmountPayableToHospital(premiumPaid, childBillGenerated);
                                    System.out.println("Amount to be paid by after insurance deduction: "+amountPayable);
                                    System.out.println("****************************************");
                                }
                                catch(NegativeAmountException n)
                                {
                                    System.out.println(n.getMessage());
                                }
                            }
                        }
                                
                                else if(age>16&"f".equalsIgnoreCase(genderstring))
                                {
                                    String hospitalName = sc.nextLine();
                                    //System.out.println(hospitalname);
                                    String hospitalAddress = sc.nextLine();
                                    //System.out.println(hospitalAddress);
                                    String adultFName = sc.nextLine();
                                    String adultLName = sc.nextLine();
                                    int insuranceID = Integer.parseInt(sc.nextLine());
                                    String lastdateString = sc.nextLine();
                                    DateFormat e = new SimpleDateFormat("MM/dd/yyyy",Locale.ENGLISH);
                                    Date lastcheckUpDate = e.parse(lastdateString);
                                    String lastCheckUpStatusString = sc.nextLine();
                                    boolean lastCheckUpStatus=Boolean.parseBoolean(lastCheckUpStatusString);
                                    
                                    if("true".equalsIgnoreCase(lastCheckUpStatusString))
                                    {
                                        String lastdoctorVisited = sc.nextLine();
                                        MaternityWard maternityWard = new MaternityWard(hospitalName, hospitalAddress, age, adultFName, gender, insuranceID, lastcheckUpDate, lastCheckUpStatus, lastdoctorVisited, adultLName);
                                        System.out.println("****************************************");
                                        System.out.println("Maternity Ward Deatils: "+maternityWard.toString());
                                        try
                                        {
                                            maternityWard.assignDocToPatient(hospitalInfo.getAvailableDoctorsList());
                                            throw new SpecialistNotFoundException("There is no available doctors in the list who are child specialist ");
                                        }
                                        catch(SpecialistNotFoundException c)
                                        {
                                            System.out.println("GynaecologistNotFoundException: "+c.getMessage());
                                        }
                                        
                                        String billingDetails=sc.nextLine();
                                        double adultBillGenerated = maternityWard.calcBill(billingDetails);
                                        System.out.println("Bill Amount Generated for Adult before Indsurance deduction:"+adultBillGenerated);
                                        System.out.println(maternityWard.getLastCheckUpDetails());
                                        String InsuranceCompany = sc.nextLine();
                                        double InsuranceCoverage= Double.parseDouble(sc.nextLine());
                                        AdultInsurance adultInsurance = new AdultInsurance(InsuranceCompany, InsuranceCoverage, age, adultFName, gender, insuranceID, lastcheckUpDate, lastCheckUpStatus, lastdoctorVisited, adultLName);
                                        System.out.println(adultInsurance.toString());
                                        try
                                        {
                                            String insurancePlanName = adultInsurance.checkHealthInsurancePlan();
                                            System.out.println("Insurance Plan Name: "+insurancePlanName);
                                        }
                                        catch(InvalidInsuranceIDException i)
                                        {
                                            System.out.println(i.getMessage());
                                        }
                                        double premiumPaid = Double.parseDouble(sc.nextLine());
                                        try
                                        {
                                            double amountPayable = adultInsurance.calcAmountPayableToHospital(premiumPaid, adultBillGenerated);
                                            System.out.println("Amount to be paid by after insurance deduction: "+amountPayable);
                                        }
                                        catch(NegativeAmountException n)
                                        {
                                            System.out.println(n.getMessage());
                                        }
                                    }
                                }
                        }
                }   
        System.out.println("****************************************");
        System.out.println("List of Doctors in Hospital: ");
                System.out.print("****************************************");
        for(Doctor q : hospitalInfo.getAvailableDoctorsList())
        {
            System.out.println(q.toString());
            System.out.print("****************************************");
                
        }
                
    }
}
                                 

	// 3(b) Else if age is greater than 16 and gender is female then scan the data like hospitalname, hospitalAddress, adultFName, adultLname of type String.
                //      also scan insuranceID of type int. lastdateString of type String.
                //      Now declare DateFormat class and initialize it to simpleDateFormat class of format "MM/dd/yyy" . Declare a varialbe of type Date and variable name as 
                //      lastCheckUpDate and parse the lastDateString. Declare a variable lastCheckUpStatusString of type String and scan the data.
                //      Declare a variable lastCheckUpStatus of type boolean. If the status is "true" is equal to status of lastCheckUpStatusString(HINT: Use .equals),
                //      then declare a variable lastDoctorVisited of type String and scan the data.

	//  3b(i) Create an object for MaternityWard class with variable name as maternityWard and initialize the multiple argument contructor of MaternityWard Class.
                    //        Test the toString method of maternity ward class. Using try catch block assign the doctor to the patient from the available doctors list in the hospital info to the patient in maternity ward.

		//    Create a variable billingDetails of type String and scan the data, also create a variable adultBillGenerated of type double and invoke the calculate bill method
                    //    of maternityWard using the scanned billing details. Print the last check updetails of the patient in maternity ward. 

	//  Create a variable InsuranceCompany of type String and scan the data, also create a variable  InsuranceCoverage of type double and parse the data
	// 3b(ii)  Now create an object for AdultInsurance of variable name adultInsurance and invoke multiple argument contructor of AdultInsurance class.
                    //         Test the toString method of adult insurance class. Using try catch block invoke the chekcHealthInsurancePlan in adultinsurance class and store the returned value in
                    //         inusrancePlanName variable of type String,create a variable premiumPaid of type double and scan the data. Now using one more try catch block
                    //         invoke the calcAmountPayableToHospital method of Adult insurance class and store the returned value in amountPayable variable of type double.
	// Else if of age comparsion ends here
             // Else part ends here
         // While loop Ends here
	//4. Iterate through the list of available doctors of type Doctor using the object of Abstarct hospital using an enhance for loop and test the toString method
 // For Loop ends
     // Main method Ends
 // Class Ends