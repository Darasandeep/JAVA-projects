/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital;

import java.util.Date;

/**
 *
 * @author Dara,sandeep kumar
 */
public class ChildInsurance extends AbstractInsurance{

    public ChildInsurance(String InsuranceCompanyName, double InsuranceCoverage, int age, String fname, char gender, int insuranceId, Date lastCheckUpDate, boolean lastCheckUpStatus, String lastDoctorVisited, String lName) {
        super(InsuranceCompanyName, InsuranceCoverage, age, fname, gender, insuranceId, lastCheckUpDate, lastCheckUpStatus, lastDoctorVisited, lName);
    }
    

      @Override
    public double calcAmountPayableToHospital(double PremiumPaid, double billGenerated) throws NegativeAmountException{
       if(PremiumPaid<0)
           throw new NegativeAmountException("premium paid cannot be negative");
        else if(PremiumPaid>billGenerated) 
       return 0.8*billGenerated;
    else if(PremiumPaid<=billGenerated&&PremiumPaid>((billGenerated)/2))
   return 0.5*billGenerated;
    else
   return 0.2*billGenerated;
     
    }

    @Override
    public String toString() {
        return   super.toString();
    }
    
    
}
