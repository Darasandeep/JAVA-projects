/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital;

import java.util.Date;
import java.util.List;

/**
 *
 * @author Dara,sandeep kumar
 */
public class ChildWard extends AbstractHospitalInfo{
private boolean appointmentStatus;

    public ChildWard() {
    }

    public ChildWard(String hospitalName, String hospitalAddress, int age, String fname, char gender, int insuranceId, Date lastCheckUpDate, boolean lastCheckUpStatus, String lastDoctorVisited, String lName) {
        super(hospitalName, hospitalAddress, age, fname, gender, insuranceId, lastCheckUpDate, lastCheckUpStatus, lastDoctorVisited, lName);
    this.appointmentStatus=false;
    }
    

    @Override
    public double calcBill(String billingDetails) {
      double bill=0.0;
      String[] item=billingDetails.split(",");
      for(String i:item){
            if(i != null){
               switch(i){
                       case "Diptheria":
                           bill = bill+10.25;
                           break;
                       case"tetanus":
                           bill =bill+12.99;
                           break;
                       case "acellular pertussis":
                           bill = bill+17.89;
                           break;
                       case "Haemophilus influenzae":
                           bill= bill+7.5;
                           break;
                       case "Pneumococcal conjugate":
                           bill=bill+9.9;
                           break;
                       default:
                           bill=bill+ EMERGENCY_FEE;
                           break;
                           
               }
            }
       }
       
       return bill+BASE_CONSULTATION_FEE;
    }
    

    @Override
    public void assignDocToPatient(List<Doctor> doctorList) throws SpecialistNotFoundException{
       
    for(Doctor temp:doctorList)  {
        if(appointmentStatus==true&&temp.getSpecialityType()=="Child Specialist"){
            appointmentStatus=true;
            String doctname=temp.getName();
            String patientname=getFname()+":"+getlName();
            getDoctorsMappedToPatients().add(doctname+":"+patientname);
            getAvailableDoctorsList().remove(doctname);
        
      
        }
    }
    }

    @Override
    public String toString() {
        return super.toString() + "\nStatus=" + appointmentStatus;
    }
    
}
