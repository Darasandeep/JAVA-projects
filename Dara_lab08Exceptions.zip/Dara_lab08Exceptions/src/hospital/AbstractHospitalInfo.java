/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hospital;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Dara,sandeep kumar
 */
public abstract class AbstractHospitalInfo extends Patient implements Hospital{
    private List<Doctor> availableDoctorsList;
    private List<String> doctorsMappedToPatients;
    private String hospitalAddress;
    private String hospitalName;

    public AbstractHospitalInfo() {
        availableDoctorsList = new ArrayList<Doctor>();
//        doctorsMappedToPatients = new ArrayList<String>();
    }

    public AbstractHospitalInfo(String hospitalName, String hospitalAddress, int age, String fname, char gender, int insuranceId, Date lastCheckUpDate, boolean lastCheckUpStatus, String lastDoctorVisited, String lName) {
        super(age, fname, gender, insuranceId, lastCheckUpDate, lastCheckUpStatus, lastDoctorVisited, lName);
        this.hospitalAddress = hospitalAddress;
        this.hospitalName = hospitalName;
    }
    
public List<Doctor>addDoctors(Doctor doctor)throws InvalidDoctorSizeException{
availableDoctorsList.add(doctor);
return availableDoctorsList;
}
    @Override
    public abstract double calcBill(String billingDetails);
    @Override
    public abstract void assignDocToPatient(List<Doctor> doctorList)throws SpecialistNotFoundException;

    public List<Doctor> getAvailableDoctorsList() {
        return availableDoctorsList;
    }

    public List<String> getDoctorsMappedToPatients() {
        return doctorsMappedToPatients;
    }

    public String getHospitalAddress() {
        return hospitalAddress;
    }

    public String getHospitalName() {
        return hospitalName;
    }

    public static double getBASE_CONSULTATION_FEE() {
        return BASE_CONSULTATION_FEE;
    }

    public static double getEMERGENCY_FEE() {
        return EMERGENCY_FEE;
    }

    public void setAvailableDoctorsList(List<Doctor> availableDoctorsList) {
        this.availableDoctorsList = availableDoctorsList;
    }
    
}
